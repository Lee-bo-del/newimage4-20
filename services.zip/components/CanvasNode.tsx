import React, { useEffect, useState, useRef } from 'react';
import { Group, Image as KonvaImage, Text as KonvaText, Rect, Line as KonvaLine } from 'react-konva';
import Konva from 'konva';
import { useCanvasStore } from '../src/store/canvasStore';
import { useSelectionStore } from '../src/store/selectionStore';
import { useHistoryStore } from '../src/store/historyStore';
import useImage from 'use-image';
import { NodeData, ToolMode, Point, Stroke } from '../types';

interface CanvasNodeProps {
  node: NodeData;
  isSelected: boolean;
  isInViewport: boolean; // Added
  toolMode: ToolMode;
  onClick: (e: Konva.KonvaEventObject<MouseEvent>) => void;
  onPointerDown?: (e: Konva.KonvaEventObject<PointerEvent>) => void;
  onDragStart: (e: Konva.KonvaEventObject<DragEvent>) => void;
  onDragEnd: (e: Konva.KonvaEventObject<DragEvent>) => void;
  onContextMenu: (e: Konva.KonvaEventObject<PointerEvent>) => void;
  onDoubleClick: () => void;
  onMouseEnter: (e: Konva.KonvaEventObject<MouseEvent>) => void;
  onMouseLeave: (e: Konva.KonvaEventObject<MouseEvent>) => void;
}

// Loading placeholder component
// Dreaming/Loading placeholder component - Scheme A
const DreamingPlaceholder: React.FC<{ width: number; height: number; progress: number; statusText: string }> = ({
  width, height, progress, statusText
}) => {
  return (
    <Group>
      {/* Dark Backdrop */}
      <Rect width={width} height={height} fill="#0f172a" cornerRadius={30} />
      
      {/* Subtle Gradient Background */}
      <Rect 
        width={width} 
        height={height} 
        fillLinearGradientStartPoint={{ x: 0, y: 0 }}
        fillLinearGradientEndPoint={{ x: width, y: height }}
        fillLinearGradientColorStops={[0, '#1e1b4b', 0.5, '#312e81', 1, '#1e1b4b']}
        opacity={0.6}
        cornerRadius={30}
      />

      {/* Progress Bar Container */}
       <Rect
        x={width * 0.15}
        y={height / 2 + 50}
        width={width * 0.7}
        height={4}
        fill="#334155"
        cornerRadius={2}
      />
      
      {/* Progress Bar Active - Neon Glow */}
      <Rect
        x={width * 0.15}
        y={height / 2 + 50}
        width={width * 0.7 * (progress / 100)}
        height={4}
        fill="#c084fc" 
        shadowColor="#a855f7"
        shadowBlur={15}
        cornerRadius={2}
      />

      {/* Cyberpunk Percentage */}
      <KonvaText
        x={0}
        y={height / 2 - 20}
        width={width}
        text={`${Math.floor(progress)}%`}
        fontSize={36}
        fontFamily="'Courier New', monospace"
        fontStyle="bold"
        fill="#e2e8f0"
        align="center"
        shadowColor="#c084fc"
        shadowBlur={10}
      />
      
      {/* Status Log */}
      <KonvaText
        x={0}
        y={height / 2 + 25}
        width={width}
        text={statusText}
        fontSize={14}
        fontFamily="'Courier New', monospace"
        fill="#94a3b8"
        align="center"
        opacity={0.9}
      />
    </Group>
  );
};

// Error placeholder component
const ErrorPlaceholder: React.FC<{ width: number; height: number; message: string }> = ({
  width, height, message
}) => {
  return (
    <Group>
      <Rect width={width} height={height} fill="#7f1d1d" opacity={0.3} cornerRadius={30} stroke="#dc2626" strokeWidth={1} />
      <KonvaText
        x={0}
        y={height / 2 - 20}
        width={width}
        text="⚠"
        fontSize={32}
        fill="#ef4444"
        align="center"
      />
      <KonvaText
        x={10}
        y={height / 2 + 20}
        width={width - 20}
        text={message || "Failed"}
        fontSize={12}
        fontFamily="monospace"
        fill="#fca5a5"
        align="center"
      />
    </Group>
  );
};

// Mask rendering layer for Inpainting
const MaskLayer: React.FC<{ strokes: Stroke[] }> = ({ strokes }) => {
  if (!strokes || strokes.length === 0) return null;

  return (
    <Group opacity={0.6} listening={false}>
       {strokes.map((stroke, i) => (
         <KonvaLine
           key={i}
           points={stroke.points.flatMap((p: Point) => [p.x, p.y])}
           stroke={stroke.color}
           strokeWidth={stroke.size}
           lineCap="round"
           lineJoin="round"
           globalCompositeOperation="source-over"
           tension={0.5}
         />
       ))}
    </Group>
  );
};

// Downloading placeholder component
const DownloadingPlaceholder: React.FC<{ width: number; height: number }> = ({
  width, height
}) => {
  return (
    <Group>
      <Rect width={width} height={height} fill="#1e293b" cornerRadius={30} />
      
      {/* Pulse Effect Circle (Static for now, maybe animate opac later if needed) */}
      <Rect 
        width={width} 
        height={height} 
        fill="#334155" 
        opacity={0.3} 
        cornerRadius={30} 
      />

      {/* Icon Background */}
      <Rect
        x={width / 2 - 40}
        y={height / 2 - 60}
        width={80}
        height={80}
        fill="#0f172a"
        cornerRadius={20}
        shadowColor="#000"
        shadowBlur={10}
        shadowOpacity={0.5}
      />

      {/* Download Icon (Text Based for Konva) */}
      <KonvaText
        x={width / 2 - 20}
        y={height / 2 - 45}
        text="⬇"
        fontSize={40}
        fill="#3b82f6"
        align="center"
      />

      {/* Status Text */}
      <KonvaText
        x={0}
        y={height / 2 + 40}
        width={width}
        text="下载原图中..."
        fontSize={16}
        fontFamily="'Courier New', monospace"
        fontStyle="bold"
        fill="#e2e8f0"
        align="center"
      />
      
      <KonvaText
        x={0}
        y={height / 2 + 65}
        width={width}
        text="Getting High-Res Asset"
        fontSize={10}
        fontFamily="sans-serif"
        fill="#64748b"
        align="center"
      />
    </Group>
  );
};

// Image node component
const ImageNode: React.FC<{ node: NodeData; progress: number; statusText: string; onLoad?: () => void }> = ({
  node, progress, statusText, onLoad
}) => {
  const [image] = useImage(node.src || '', 'anonymous');

  useEffect(() => {
    if (image && onLoad) {
      onLoad();
    }
  }, [image, onLoad]);

  if (node.loading) {
    return <DreamingPlaceholder width={node.width} height={node.height} progress={progress} statusText={statusText} />;
  }

  if (node.error) {
    return <ErrorPlaceholder width={node.width} height={node.height} message={node.errorMessage || 'Failed'} />;
  }

  if (!image) {
    return <DownloadingPlaceholder width={node.width} height={node.height} />;
  }

  return (
    <Group
      clipFunc={(ctx) => {
        ctx.beginPath();
        ctx.roundRect(0, 0, node.width, node.height, 30);
        ctx.closePath();
      }}
    >
      <KonvaImage
        image={image}
        width={node.width}
        height={node.height}
      />
      
      {/* Show Inpaint Mask if present */}
      {node.maskStrokes && node.maskStrokes.length > 0 && (
        <MaskLayer strokes={node.maskStrokes} />
      )}
    </Group>
  );
};

// Video node component
const VideoNode: React.FC<{ node: NodeData; progress: number; statusText: string; isInViewport: boolean }> = ({
  node, progress, statusText, isInViewport
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const imageRef = useRef<Konva.Image>(null);
  const [videoImage, setVideoImage] = useState<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  // Access store to update node dimensions
  const updateNode = useCanvasStore(state => state.updateNode);

  useEffect(() => {
    if (!node.src || node.type !== 'VIDEO') return;

    if (!videoRef.current) {
      const vid = document.createElement('video');
      vid.src = node.src;
      vid.crossOrigin = 'anonymous';
      vid.loop = true;
      vid.muted = true; // Start muted

      // Fix Ratio on load & Force Frame Render
      vid.onloadedmetadata = () => {
        const videoWidth = vid.videoWidth;
        const videoHeight = vid.videoHeight;
        if (videoWidth && videoHeight) {
          // Adjust node height to match video aspect ratio, keeping current width
          const newHeight = node.width * (videoHeight / videoWidth);
          // Only update if significantly different to avoid loops
          if (Math.abs(newHeight - node.height) > 1) {
            updateNode(node.id, { height: newHeight });
          }
        }
        // Force seek to grab first frame (sometimes 0 doesn't render if keyframe is weird, 0.1 is safer)
        vid.currentTime = 0.1;
      };

      videoRef.current = vid;
      setVideoImage(vid);
    } else if (videoRef.current.src !== node.src) {
      videoRef.current.src = node.src;
      setIsPlaying(false);
    }

    return () => {
      if (videoRef.current) {
        videoRef.current.pause();
      }
    };
  }, [node.src, node.width, node.height, node.id, updateNode]);

  // Handle Play/Pause effect including Viewport Optimization
  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;

    if (isPlaying && isInViewport) {
      vid.muted = isMuted;
      vid.play().catch(e => {
        console.warn("Video play failed", e);
        setIsPlaying(false);
      });
    } else {
      vid.pause();
    }
  }, [isPlaying, isMuted, isInViewport]); // Added isInViewport

  // Efficient Animation Loop using Konva.Animation
  useEffect(() => {
    if (!videoImage || !isPlaying || !imageRef.current) return;

    const anim = new Konva.Animation(() => {
      // Intentionally empty, just need the loop to trigger layer draw?
      // Actually, Konva.Image needs to be redrawn.
      // With react-konva, if we manipulate the Konva node directly, we might need manual draw.
      // But typically, simply passing the video element to Konva.Image is enough IF the layer is redrawn.
      // Konva.Animation on the layer is the standard way.
    }, imageRef.current.getLayer());

    anim.start();
    return () => { anim.stop(); }; // Fix return type
  }, [videoImage, isPlaying]);

  const togglePlay = (e: Konva.KonvaEventObject<MouseEvent>) => {
    // Let it bubble so node selection works too
    setIsPlaying(prev => !prev);
  };

  const toggleMute = (e: Konva.KonvaEventObject<MouseEvent>) => {
    e.cancelBubble = true;
    setIsMuted(prev => !prev);
  };

  if (node.loading) {
    return <DreamingPlaceholder width={node.width} height={node.height} progress={progress} statusText={statusText || "视频生成中..."} />;
  }

  if (node.error) {
    return <ErrorPlaceholder width={node.width} height={node.height} message={node.errorMessage || 'Failed'} />;
  }

  if (!videoImage) {
    return <Rect width={node.width} height={node.height} fill="#000" cornerRadius={30} />;
  }

  return (
    <Group>
      <Group
        clipFunc={(ctx) => {
          ctx.beginPath();
          ctx.roundRect(0, 0, node.width, node.height, 30);
          ctx.closePath();
        }}
        onClick={togglePlay}
        onTap={togglePlay as any}
      >
        <KonvaImage
          ref={imageRef}
          image={videoImage}
          width={node.width}
          height={node.height}
          // cornerRadius removed as we clip parent
        />
      </Group>

      {/* Controls Overlay - Show when paused or hovering (hover logic hard in canvas, just show when paused) */}
      {!isPlaying && (
        <Group x={node.width / 2 - 25} y={node.height / 2 - 25} onClick={togglePlay} onTap={togglePlay as any}>
          <Rect width={50} height={50} fill="rgba(0,0,0,0.6)" cornerRadius={25} />
          <KonvaText text="▶" x={18} y={15} fontSize={24} fill="#fff" listening={false} />
        </Group>
      )}

      {/* Mute Control (Bottom Right) */}
      <Group x={node.width - 40} y={node.height - 40} onClick={toggleMute} onTap={toggleMute as any}>
        <Rect width={32} height={32} fill="rgba(0,0,0,0.5)" cornerRadius={4} />
        <KonvaText
          text={isMuted ? "🔇" : "🔊"}
          x={6}
          y={8}
          fontSize={16}
          fill="#fff"
          listening={false}
        />
      </Group>

      {/* Play/Pause Click Area (Entire Node? or just center?) 
          Let's verify play by clicking center button. 
      */}
    </Group>
  );
};

// Helper for dynamic progress text
// Helper for dynamic progress text (Cyberpunk Style)
const getProgressText = (progress: number): string => {
  if (progress < 20) return "正在解析语义空间...";
  if (progress < 40) return "构建几何骨架...";
  if (progress < 60) return "注入光影细节...";
  if (progress < 80) return "渲染纹理...";
  return "最终润色...";
};

// Memoize the component to prevent re-renders when other nodes update
const CanvasNode: React.FC<CanvasNodeProps> = React.memo(({
  node,
  isSelected,
  isInViewport,
  toolMode,
  onClick,
  onPointerDown,
  onDragStart,
  onDragEnd,
  onContextMenu,
  onDoubleClick,
  onMouseEnter,
  onMouseLeave
}) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("初始化中...");
  const [isResourceLoaded, setIsResourceLoaded] = useState(false);

  const updateNode = useCanvasStore(state => state.updateNode);
  const apiKey = useSelectionStore(state => state.apiKey);
  const addLog = useHistoryStore(state => state.addLog);

  // Polling Hook REMOVED - using global polling in App.tsx now
  // const { data: taskData } = useGenerationTask(apiKey, node.loading ? node.taskId : undefined);

  // Effect to handle polling updates REMOVED
  // Global manager handles store updates. We only handle visual simulation here.

  // Simulation Effect for Loading Experience Scheme A
  useEffect(() => {
    if (!node.loading) {
      setProgress(0);
      return;
    }

    const startTime = Date.now();
    const duration = 70000; // 70s to 90%
    
    // Initial jump and text
    setProgress(1);
    setStatusText(getProgressText(1));

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      
      let p = 0;
      if (elapsed < duration) {
        // Phase 1: 0-70s -> 0-90% (Linear)
        p = (elapsed / duration) * 90;
      } else {
        // Phase 2: >70s -> 90-99% (Asymptotic slow crawl)
        const extraTime = elapsed - duration;
        p = 90 + (1 - Math.exp(-extraTime / 20000)) * 9;
      }
      
      // Never exceed 99% until success signal comes
      p = Math.min(p, 99);
      setProgress(p);
      setStatusText(getProgressText(p));
      
    }, 100);

    return () => clearInterval(interval);
  }, [node.loading, node.id]); // Reset on loading change

  const isDraggable = !node.locked && toolMode === ToolMode.SELECT;

  // Cache configuration
  const groupRef = useRef<Konva.Group>(null);
  
  // Cache configuration for performance optimization
  useEffect(() => {
    if (groupRef.current) {
        // Only cache if the node is "quiet" to avoid blurriness or stale frames
        // AND ensure the resource (image) is actually loaded
        const isQuiet = !isSelected && !node.loading && !node.dragging && isResourceLoaded;
        
        if (isQuiet && node.type === 'IMAGE') {
            // Apply cache with a slight delay to ensure the image is actually rendered
            const timer = setTimeout(() => {
                if (groupRef.current && isResourceLoaded) {
                    groupRef.current.cache();
                    groupRef.current.getLayer()?.batchDraw();
                }
            }, 200);
            return () => clearTimeout(timer);
        } else {
            groupRef.current.clearCache();
        }
    }
  }, [isSelected, node.loading, node.dragging, node.type, isInViewport, isResourceLoaded]);

  return (
    <Group
      id={`node-${node.id}`}
      ref={groupRef}
      x={node.x}
      y={node.y}
      width={node.width}
      height={node.height}
      draggable={isDraggable}
      opacity={node.opacity ?? 1}
      onClick={onClick}
      onPointerDown={onPointerDown}
      onTap={(e) => onClick(e as unknown as Konva.KonvaEventObject<MouseEvent>)}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onContextMenu={onContextMenu}
      onDblClick={onDoubleClick}
      onDblTap={onDoubleClick}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      // Performance flags
      perfectDrawEnabled={false}
      shadowForStrokeEnabled={false}
      hitStrokeWidth={0} // Improves hit detection perf
    >
      {node.type === 'VIDEO' ? (
        <VideoNode node={node} progress={progress} statusText={statusText} isInViewport={isInViewport} />
      ) : (
        <ImageNode node={node} progress={progress} statusText={statusText} onLoad={() => setIsResourceLoaded(true)} />
      )}

      {isSelected && (
        <Rect
          width={node.width}
          height={node.height}
          stroke="#3b82f6"
          strokeWidth={2}
          dash={[5, 5]}
          cornerRadius={30}
          listening={false}
          perfectDrawEnabled={false}
          shadowForStrokeEnabled={false}
        />
      )}

      {node.locked && (
        <Group x={node.width - 24} y={4}>
          <Rect
            width={20}
            height={20}
            fill="rgba(0,0,0,0.5)"
            cornerRadius={10}
            perfectDrawEnabled={false}
          />
          <KonvaText
            x={4}
            y={2}
            text="🔒"
            fontSize={12}
            perfectDrawEnabled={false}
          />
        </Group>
      )}
    </Group>
  );
});

export default CanvasNode;
