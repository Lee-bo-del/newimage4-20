import { useQueries } from '@tanstack/react-query';
import { useCanvasStore } from '../store/canvasStore';
import { checkTaskStatus, checkVideoTaskStatus, findAllUrlsInObject } from '../services/api';
import { useEffect, useRef } from 'react';
import { useToast } from '../context/ToastContext';

export const useGlobalPolling = (
  apiKey: string | undefined,
  onUpdateGeneration: (id: string, src: string | null, error?: string) => void,
  onUpdateProgress: (id: string, progress: number) => void
) => {
  const nodes = useCanvasStore((state) => state.nodes);
  const { error: toastError } = useToast();
  
  // Filter nodes that need polling (loading + has taskId)
  const pendingNodes = nodes.filter(n => n.loading && n.taskId && !n.error);

  const queries = useQueries({
    queries: pendingNodes.map(node => ({
      queryKey: ['task', node.taskId],
      queryFn: async () => {
        if (!apiKey || !node.taskId) return null;
        try {
            const data = node.type === 'VIDEO' 
                ? await checkVideoTaskStatus(apiKey, node.taskId)
                : await checkTaskStatus(apiKey, node.taskId);
            let statusRaw = (data.status || data.state || "").toUpperCase();
            
            // Deep search for status (same logic as before)
            if (!statusRaw || statusRaw === "UNKNOWN") {
                const findStatusInObject = (obj: any): string | null => {
                    if (!obj || typeof obj !== 'object') return null;
                    if (obj.status && typeof obj.status === 'string') return obj.status;
                    if (obj.state && typeof obj.state === 'string') return obj.state;
                    if (obj.data && typeof obj.data === 'object') return findStatusInObject(obj.data);
                    return null;
                };
                const inner = findStatusInObject(data);
                if (inner) statusRaw = inner.toUpperCase();
            }

            const isSuccess = statusRaw === 'SUCCESS' || statusRaw === 'SUCCEEDED' || statusRaw === 'COMPLETED';
            const isFailed = statusRaw === 'FAILURE' || statusRaw === 'FAILED';
            
            const resultUrls: string[] = [];
            if (isSuccess) {
                findAllUrlsInObject(data, resultUrls);
            }

            return {
                id: node.id, // Pass node ID for correlation
                taskId: node.taskId,
                status: statusRaw,
                isSuccess,
                isFailed,
                urls: Array.from(new Set(resultUrls)),
                raw: data
            };
        } catch (e) {
            console.warn(`Polling failed and will retry for task ${node.taskId}`, e);
            throw e; // Throw to trigger query retry logic
        }
      },
      refetchInterval: (query: any) => {
        const data = query.state.data;
        if (data && (data.isSuccess || data.isFailed)) return false;
        return 5000; // Poll every 5s (reduced from 3s to save requests)
      },
      retry: 3,
      enabled: !!apiKey
    }))
  });

  // Track processed tasks to avoid re-processing with a ref
  const processedTasksRef = useRef<Map<string, { success: boolean; failed: boolean }>>(new Map());

  // Effect to process results - single useEffect with proper dependencies
  useEffect(() => {
    queries.forEach((result) => {
        const data = result.data;
        if (!data || !data.taskId) return;

        // Get current processing state
        const processedState = processedTasksRef.current.get(data.taskId) || { success: false, failed: false };

        // If success and not yet processed
        if (data.isSuccess && !processedState.success && data.urls.length > 0) {
             processedTasksRef.current.set(data.taskId, { ...processedState, success: true });
             onUpdateGeneration(data.id, data.urls[0]);
        } 
        // If failed and not yet processed
        else if (data.isFailed && !processedState.failed) {
             processedTasksRef.current.set(data.taskId, { ...processedState, failed: true });
             let errorMsg = "Generation Failed";
             const raw = data.raw;
             
             // Extract specific error details
             if (raw?.fail_reason) {
                 errorMsg = raw.fail_reason;
             } else if (raw?.data?.fail_reason) {
                 errorMsg = raw.data.fail_reason;
             } else if (raw?.error?.message) {
                 errorMsg = raw.error.message;
             } else if (typeof raw?.error === 'string') {
                 errorMsg = raw.error;
             } else if (raw?.result?.error) {
                 errorMsg = raw.result.error;
             } else if (raw?.data?.error) {
                 errorMsg = raw.data.error;
             }
             
             // Map backend errors to user-friendly advice (check immediately after extraction)
             let errorMapped = false;
             
             // Content policy rejection
             if (errorMsg.includes("Gemini could not generate an image with the given prompt")) {
                 errorMsg = "生成失败：提示词或参考图不符合AI伦理要求，请修改后重试";
                 errorMapped = true;
             }
             // Server overload / rate limit
             else if (errorMsg.includes("负载已饱和") || errorMsg.includes("请稍后再试")) {
                 errorMsg = "算力紧张，使用峰期，谷歌限制并发，需要排队，建议晚点使用谷期再试";
                 errorMapped = true;
             }
             // Service unavailable / configuration issue
             else if (errorMsg.includes("无可用渠道") || errorMsg.includes("请联系管理员")) {
                 errorMsg = "服务暂时不可用，请稍后重试或联系管理员";
                 errorMapped = true;
             }
             
             // Handle Safety/Block reasons (Gemini/Vertex specific structure) - only if not already mapped
             if (!errorMapped) {
                 if (raw?.promptFeedback?.blockReason) {
                     errorMsg = `Blocked: ${raw.promptFeedback.blockReason}`;
                 } else if (raw?.candidates?.[0]?.finishReason && raw.candidates[0].finishReason !== 'STOP') {
                     errorMsg = `Stopped: ${raw.candidates[0].finishReason}`;
                     // Check safety ratings
                     const safety = raw.candidates[0].safetyRatings;
                     if (safety && Array.isArray(safety)) {
                         const unsafe = safety.find((r: any) => r.probability === 'HIGH' || r.probability === 'MEDIUM');
                         if (unsafe) {
                             errorMsg += ` (Safety: ${unsafe.category})`;
                         }
                     }
                 }
             }

             onUpdateGeneration(data.id, null, errorMsg);
             toastError(`${errorMsg}`);
        }
    });
    
    // Clean up old processed tasks periodically (keep only last 50)
    if (processedTasksRef.current.size > 50) {
      const entries = Array.from(processedTasksRef.current.entries());
      processedTasksRef.current = new Map(entries.slice(-50));
    }
  }, [queries.map(q => q.data?.taskId + q.data?.status).join(','), onUpdateGeneration, toastError]);

};
