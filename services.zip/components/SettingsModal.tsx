import React, { useState, useEffect } from 'react';
import { X, Key, CreditCard, ShoppingCart, Loader2, History, Settings, RotateCcw, Trash2, Eye, EyeOff, Download, ImagePlus, Maximize2, DownloadCloud, Info, Film, AlertCircle, Megaphone, Save } from 'lucide-react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { checkBalance } from '../services/geminiService';
import { useHistoryStore } from '../src/store/historyStore';
import { useSelectionStore } from '../src/store/selectionStore';
import wechatQR from '../src/assets/wechat_qr.png';
import GlassModal from './GlassModal';
import CoinIcon from './CoinIcon';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReusePrompt?: (prompt: string, type: 'image' | 'video') => void;
  onViewImage?: (src: string) => void;
  onDownloadImage?: (src: string, prompt?: string, id?: string) => void;
  onUseAsReference?: (src: string) => void;
  initialTab?: 'settings' | 'history';
}

const ResolvedHistoryItem = ({ 
  log, 
  historyMediaType, 
  onViewImage, 
  handleReusePrompt, 
  onUseAsReference, 
  onDownloadImage 
}: { 
  log: any; 
  historyMediaType: 'image' | 'video';
  onViewImage?: (src: string) => void;
  handleReusePrompt: (prompt: string) => void;
  onUseAsReference?: (src: string) => void;
  onDownloadImage?: (src: string, prompt?: string, id?: string) => void;
}) => {
  const [resolvedUrl, setResolvedUrl] = useState<string>(log.imageUrl);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    let active = true;
    const resolveAsset = async () => {
      // If image is a local blob and we have an assetId, try to retrieve it fresh
      if (log.assetId && (log.imageUrl.startsWith('blob:') || hasError)) {
        try {
          const freshUrl = await import('../src/services/assetStorage').then(m => m.assetStorage.getAssetUrl(log.assetId!));
          if (freshUrl && active) {
            setResolvedUrl(freshUrl);
            setHasError(false);
          }
        } catch (e) {
          console.warn("Could not resolve asset blob for history item", log.assetId);
        }
      }
    };
    resolveAsset();
    return () => { active = false; };
  }, [log.assetId, log.imageUrl, hasError]);

  return (
    <div
      key={log.id}
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData('text/plain', resolvedUrl);
        e.dataTransfer.effectAllowed = 'copy';
      }}
      className="group relative w-full bg-gray-900/40 rounded-xl overflow-hidden border border-white/5 hover:border-white/20 transition-all cursor-grab active:cursor-grabbing"
    >
      {historyMediaType === 'video' ? (
        <video
          src={resolvedUrl}
          className="w-full h-auto block"
          muted
          loop
          playsInline
          onMouseOver={e => e.currentTarget.play().catch(console.warn)}
          onMouseOut={e => e.currentTarget.pause()}
          onError={() => setHasError(true)}
        />
      ) : (
        <img
          src={resolvedUrl}
          alt={log.prompt}
          className="w-full h-auto block"
          loading="lazy"
          onError={() => setHasError(true)}
        />
      )}
      
      {/* Action Overlay */}
      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all duration-200 flex flex-col justify-end p-2">
        <div className="flex justify-center gap-2 mb-2">
            {/* Zoom/Play Button (Common) */}
            <button 
                onClick={() => onViewImage && onViewImage(resolvedUrl)}
                className="p-1.5 bg-white/20 hover:bg-blue-500 text-white rounded-lg backdrop-blur-sm transition-colors"
                title={historyMediaType === 'video' ? "播放" : "放大查看"}
            >
                {historyMediaType === 'video' ? <Film size={14} /> : <Maximize2 size={14} />}
            </button>

            {/* Reuse Prompt (Common) */}
            <button 
                onClick={() => handleReusePrompt(log.prompt)}
                className="p-1.5 bg-white/20 hover:bg-blue-500 text-white rounded-lg backdrop-blur-sm transition-colors"
                title="再次生成"
            >
                <RotateCcw size={14} />
            </button>

             {/* Reference (Image Only) */}
            {historyMediaType === 'image' && (
                <button 
                    onClick={() => onUseAsReference && onUseAsReference(resolvedUrl)}
                    className="p-1.5 bg-white/20 hover:bg-purple-500 text-white rounded-lg backdrop-blur-sm transition-colors"
                    title="用作参考图"
                >
                    <ImagePlus size={14} />
                </button>
            )}

            {/* Download (Common) */}
            <button 
                onClick={() => onDownloadImage && onDownloadImage(resolvedUrl, log.prompt, log.id)}
                className="p-1.5 bg-white/20 hover:bg-green-500 text-white rounded-lg backdrop-blur-sm transition-colors"
                title="下载"
            >
                <Download size={14} />
            </button>
        </div>
        <p className="text-[10px] text-gray-300 line-clamp-2 leading-tight opacity-80">{log.prompt}</p>
      </div>
    </div>
  );
};

const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onReusePrompt,
  onViewImage,
  onDownloadImage,
  onUseAsReference,
  initialTab = 'settings'
}) => {
  const { apiKey, setApiKey } = useSelectionStore();
  const [activeTab, setActiveTab] = useState<'settings' | 'history'>(initialTab);
  const [showApiKey, setShowApiKey] = useState(false);
  const [isCheckingBal, setIsCheckingBal] = useState(false);
  const [isDownloadingAll, setIsDownloadingAll] = useState(false);
  const [balanceData, setBalanceData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [isConfirmingClear, setIsConfirmingClear] = useState(false);
  const { logs = [], clearLogs } = useHistoryStore();
  const safeLogs = Array.isArray(logs) ? logs : [];

  // Announcement State
  const [announcementForm, setAnnouncementForm] = useState({ title: '', content: '', active: false, password: '' });
  const [isSavingAnnouncement, setIsSavingAnnouncement] = useState(false);
  const [isAnnouncementExpanded, setIsAnnouncementExpanded] = useState(false);

  useEffect(() => {
    if (isOpen && activeTab === 'settings') {
      fetch('/api/announcement')
        .then(res => res.json())
        .then(data => {
            if(data) setAnnouncementForm({ title: data.title || '', content: data.content || '', active: data.active || false, password: '' });
        })
        .catch(err => console.error("Failed to load announcement", err));
    }
  }, [isOpen, activeTab]);

  const handleSaveAnnouncement = async () => {
    if (!apiKey) {
      setError("发布公告需要配置 API Key");
      return;
    }
    setIsSavingAnnouncement(true);
    try {
      const res = await fetch('/api/announcement', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'Authorization': apiKey,
          'x-admin-password': announcementForm.password // Send admin password
        },
        body: JSON.stringify({ 
          title: announcementForm.title, 
          content: announcementForm.content, 
          active: announcementForm.active 
        })
      });
      const data = await res.json();
      if (res.ok) {
        alert("公告发布成功！刷新页面即可看到效果。");
        setIsAnnouncementExpanded(false);
      } else {
        alert("发布失败: " + (data.error || "未知错误"));
      }
    } catch (e) {
      alert("发布失败: 网络错误");
    } finally {
      setIsSavingAnnouncement(false);
    }
  };

  const [historyMediaType, setHistoryMediaType] = useState<'image' | 'video'>('image');

  const filteredLogs = safeLogs.filter(log => {
    const isVideo = log.imageUrl?.toLowerCase().endsWith('.mp4') || log.imageUrl?.toLowerCase().includes('format=mp4');
    return historyMediaType === 'video' ? isVideo : !isVideo;
  });

  // Sync activeTab with initialTab when opening
  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);



  const handleApiKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setApiKey(e.target.value);
  };

  const handleCheckBalance = async () => {
    if (!apiKey) {
      setError("请先输入 API Key (密钥)");
      return;
    }
    setIsCheckingBal(true);
    setError(null);
    try {
      const data = await checkBalance(apiKey);
      if (data.success) {
        setBalanceData(data);
      } else {
        setError("查询失败：未知错误");
      }
    } catch (e: any) {
      if (e.message.includes('fetch') || e.message.includes('Network Error')) {
        setError("连接失败：请确保后端服务正在运行");
      } else {
        setError("查询失败：" + e.message);
      }
    } finally {
      setIsCheckingBal(false);
    }
  };

  const handleReusePrompt = (prompt: string) => {
    if (onReusePrompt) {
      onReusePrompt(prompt, historyMediaType);
      onClose();
    }
  };

  const handleClearHistory = () => {
    if (safeLogs.length === 0) return;
    if (!isConfirmingClear) {
      setIsConfirmingClear(true);
      // Auto-cancel after 3 seconds if not clicked again
      setTimeout(() => setIsConfirmingClear(false), 3000);
      return;
    }
    clearLogs();
    setIsConfirmingClear(false);
  };

  const handleDownloadAll = async () => {
    if (safeLogs.length === 0) return;
    setIsDownloadingAll(true);
    try {
      const zip = new JSZip();

      const downloadPromises = safeLogs.map(async (log, index) => {
        try {
          // fetch works for both URL and DataURL
          const response = await fetch(log.imageUrl);
          const blob = await response.blob();

          const cleanPrompt = (log.prompt || 'image').slice(0, 30).replace(/[^a-z0-9]/gi, '_').trim();
          const ext = blob.type.split('/')[1] || 'png';
          // reverse index so newest is highest number or just keep it simple
          const filename = `${String(safeLogs.length - index).padStart(3, '0')}_${cleanPrompt}.${ext}`;
          zip.file(filename, blob);
        } catch (e) {
          console.error("Batch download: failed to fetch image", log.imageUrl, e);
        }
      });

      await Promise.all(downloadPromises);
      const content = await zip.generateAsync({ type: "blob" });
      saveAs(content, `history_images_${new Date().toISOString().split('T')[0]}.zip`);
    } catch (err) {
      console.error("Batch download zip failed", err);
      alert("批量下载失败，请重试");
    } finally {
      setIsDownloadingAll(false);
    }
  };


  return (
    <GlassModal
      isOpen={isOpen}
      onClose={onClose}
      title={activeTab === 'settings' ? '全局设置' : '历史记录'}
      width="max-w-2xl"
      className="h-[80vh] relative"
    >
      <div className="flex flex-col h-full bg-transparent">
        {/* Content */}
        <div className="flex-1 p-6">
          {activeTab === 'settings' ? (
            /* Settings Tab */
            <div className="space-y-6">
              <div>
                <label className="text-xs font-medium text-gray-400 mb-2 flex items-center gap-1.5 uppercase tracking-wider">
                  <Key size={12} /> API Key (密钥)
                </label>
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      value={apiKey}
                      onChange={handleApiKeyChange}
                      placeholder="输入 API Key"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pr-10 text-sm text-gray-200 placeholder-gray-600 focus:border-white/20 focus:bg-white/10 focus:outline-none transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors p-1"
                      title={showApiKey ? '隐藏密钥' : '显示密钥'}
                    >
                      {showApiKey ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  <button 
                    onClick={onClose}
                    className="bg-purple-600/80 hover:bg-purple-500 text-white px-5 py-3 rounded-xl flex items-center gap-2 text-sm font-medium transition-all active:scale-95 shadow-lg shadow-purple-500/20"
                  >
                    <Save size={16} /> 保存
                  </button>
                </div>
              </div>

              {/* Balance & Purchase Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleCheckBalance}
                  disabled={isCheckingBal}
                  className="flex-1 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white text-sm py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                  {isCheckingBal ? <Loader2 size={16} className="animate-spin" /> : <CreditCard size={16} />}
                  查询余额
                </button>
                <a
                  href="https://item.taobao.com/item.htm?id=975150888957"
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 bg-linear-to-r from-orange-500/20 to-red-500/20 hover:from-orange-500/30 hover:to-red-500/30 border border-orange-500/30 text-orange-200 hover:text-orange-100 text-sm py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 no-underline"
                >
                  <ShoppingCart size={16} />
                  购买额度
                </a>
              </div>

              {/* Balance Display */}
              {balanceData && (
                <div className="bg-white/5 p-5 rounded-2xl border border-white/10 space-y-4">
                  <div className="text-center">
                    <div className="text-xs text-gray-500 mb-1 uppercase tracking-wider">剩余可用额度</div>
                    <div className="text-4xl font-mono font-bold text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.2)] flex items-center justify-center gap-2">
                      <CoinIcon size={28} className="drop-shadow-sm" />
                      {balanceData.remaining_points}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-black/20 p-3 rounded-xl border border-white/5 text-center">
                      <div className="text-[10px] text-gray-500 mb-1">已用额度</div>
                      <div className="text-sm font-mono text-gray-300 flex items-center justify-center gap-1">
                        <CoinIcon size={14} />
                        {balanceData.used_points}
                      </div>
                    </div>
                    <div className="bg-black/20 p-3 rounded-xl border border-white/5 text-center">
                      <div className="text-[10px] text-gray-500 mb-1">总额度</div>
                      <div className="text-sm font-mono text-gray-300 flex items-center justify-center gap-1">
                        <CoinIcon size={14} />
                        {balanceData.total_points}
                      </div>
                    </div>
                  </div>
                  <div className="text-[10px] text-gray-500 text-center pt-3 border-t border-white/5 leading-relaxed">
                    {/* 规则说明已移除 */}
                  </div>
                </div>
              )}

              {/* Tech Support */}
              {/* Tech Support - Premium Card Style */}
              {/* Tech Support - Premium Card Style (Moved to bottom left absolute) */}

              {/* Announcement Manager (Hidden unless API Key is specific admin key) */}
              {apiKey === 'sk-K9OJf52OughwT8vizrDKJpvMebzutpbKVXxxhYe8EZFF0nm7' && (
              <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5">
                <button 
                  onClick={() => setIsAnnouncementExpanded(!isAnnouncementExpanded)}
                  className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
                >
                  <label className="text-xs font-medium text-gray-400 flex items-center gap-1.5 uppercase tracking-wider cursor-pointer">
                    <Megaphone size={12} /> 公告管理 (Admin)
                  </label>
                  <div className={`text-xs px-2 py-0.5 rounded-full ${announcementForm.active ? 'bg-green-500/20 text-green-300' : 'bg-gray-700 text-gray-400'}`}>
                    {announcementForm.active ? '已启用' : '未启用'}
                  </div>
                </button>
                
                {isAnnouncementExpanded && (
                  <div className="p-4 border-t border-white/10 space-y-4 bg-black/20">
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">标题</label>
                      <input 
                        value={announcementForm.title}
                        onChange={e => setAnnouncementForm({...announcementForm, title: e.target.value})}
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-white/20 focus:outline-none"
                        placeholder="系统公告"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">管理员密码</label>
                      <input 
                        type="password"
                        value={announcementForm.password}
                        onChange={e => setAnnouncementForm({...announcementForm, password: e.target.value})}
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-white/20 focus:outline-none placeholder-gray-700"
                        placeholder="请输入管理密码 (默认 admin888)"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">内容</label>
                      <textarea 
                        value={announcementForm.content}
                        onChange={e => setAnnouncementForm({...announcementForm, content: e.target.value})}
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-sm text-gray-200 focus:border-white/20 focus:outline-none min-h-[100px]"
                        placeholder="输入公告内容..."
                      />
                    </div>
                    <div className="flex items-center justify-between">
                       <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                         <input 
                           type="checkbox" 
                           checked={announcementForm.active}
                           onChange={e => setAnnouncementForm({...announcementForm, active: e.target.checked})}
                           className="w-4 h-4 rounded border-gray-600 bg-black/40 text-blue-500 focus:ring-offset-0"
                         />
                         启用公告弹窗
                       </label>
                       <button
                         onClick={handleSaveAnnouncement}
                         disabled={isSavingAnnouncement}
                         className="px-4 py-2 bg-blue-600/80 hover:bg-blue-600 text-white text-xs rounded-lg flex items-center gap-2 transition-all disabled:opacity-50"
                       >
                         {isSavingAnnouncement ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
                         立即发布
                       </button>
                    </div>
                  </div>
                )}
              </div>
              )}

              {/* Error Display */}
              {error && (
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3 text-red-200 text-xs">
                  <AlertCircle size={16} className="shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}
            </div>
          ) : (
            /* History Tab */
            <div className="space-y-4">
              <div className="flex gap-2 bg-black/20 p-1.5 rounded-xl border border-white/5">
                <button
                  onClick={() => setHistoryMediaType('image')}
                  className={`flex-1 text-xs py-2 rounded-lg transition-all font-medium ${historyMediaType === 'image'
                    ? 'bg-white/10 text-white shadow-sm ring-1 ring-white/10'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
                    }`}
                >
                  图片历史
                </button>
                <button
                  onClick={() => setHistoryMediaType('video')}
                  className={`flex-1 text-xs py-2 rounded-lg transition-all font-medium ${historyMediaType === 'video'
                    ? 'bg-purple-500/20 text-purple-200 shadow-sm ring-1 ring-purple-500/20'
                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
                    }`}
                >
                  视频历史
                </button>
              </div>

              {filteredLogs.length > 0 && (
                <div className="flex justify-between items-center px-1">
                   <span className="text-xs text-gray-500">共 {filteredLogs.length} 条记录</span>
                   <button
                     onClick={handleDownloadAll}
                     disabled={isDownloadingAll}
                     className={`text-xs flex items-center gap-1.5 transition-colors ${isDownloadingAll ? 'text-gray-600' : 'text-blue-400 hover:text-blue-300'}`}
                   >
                     {isDownloadingAll ? <Loader2 size={12} className="animate-spin" /> : <DownloadCloud size={12} />}
                     全部打包下载
                   </button>
                </div>
              )}

              {filteredLogs.length > 0 ? (
                <div className="grid grid-cols-3 gap-3 pb-8 items-start">
                  {[0, 1, 2].map((colIndex) => (
                    <div key={colIndex} className="flex flex-col gap-3">
                      {filteredLogs.filter((_, i) => i % 3 === colIndex).map((log) => (
                        <ResolvedHistoryItem
                          key={log.id}
                          log={log}
                          historyMediaType={historyMediaType}
                          onViewImage={onViewImage}
                          handleReusePrompt={handleReusePrompt}
                          onUseAsReference={onUseAsReference}
                          onDownloadImage={onDownloadImage}
                        />
                      ))}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-gray-600">
                  <History size={48} strokeWidth={1} className="mb-4 opacity-20" />
                  <p className="text-sm">暂无生成记录</p>
                  <p className="text-xs opacity-50 mt-1">您生成的图片和视频会自动保存在这里</p>
                </div>
              )}
              
              {filteredLogs.length > 0 && (
                <div className="pt-4 border-t border-white/5">
                   <button
                    onClick={handleClearHistory}
                    className={`w-full py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-all ${
                        isConfirmingClear 
                        ? 'bg-red-500/20 text-red-300 border border-red-500/30' 
                        : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-gray-300'
                    }`}
                   >
                     <Trash2 size={14} />
                     {isConfirmingClear ? '确定清空所有记录？' : '清空记录'}
                   </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {activeTab === 'settings' && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 pointer-events-none">
          <div 
            onClick={() => onViewImage && onViewImage(wechatQR)}
            className="bg-white/10 backdrop-blur-md rounded-xl p-2 border border-white/10 shadow-2xl pointer-events-auto group hover:scale-105 transition-transform duration-300 cursor-zoom-in"
            title="点击放大展示二维码"
          >
            <img 
              src={wechatQR} 
              alt="WeChat QR" 
              className="w-24 h-24 rounded-lg opacity-90 group-hover:opacity-100 transition-opacity" 
            />
          </div>
          <div className="text-[10px] font-medium text-gray-500 uppercase tracking-[0.2em] opacity-50">
            扫码联系技术支持
          </div>
        </div>
      )}
    </GlassModal>
  );
};

export default SettingsModal;
