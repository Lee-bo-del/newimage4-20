import React, { useEffect, useState } from 'react';
import { X, Megaphone, Bell } from 'lucide-react';

interface Announcement {
  id: string;
  title: string;
  content: string;
  active: boolean;
  date: string;
}

const AnnouncementPopup: React.FC = () => {
  const [announcement, setAnnouncement] = useState<Announcement | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Check for announcements on mount
    // Silently fail if rate limited to prevent blocking the app
    fetch('/api/announcement')
      .then(res => {
        if (!res.ok) {
          // Silently ignore errors (e.g., rate limiting, server down)
          console.warn(`[Announcement] Failed to fetch: ${res.status}`);
          return null;
        }
        return res.json();
      })
      .then((data: Announcement | null) => {
        if (data && data.active && data.content) {
          // Check if already seen
          const seenId = localStorage.getItem('seen_announcement_id');
          if (seenId !== data.id) {
            setAnnouncement(data);
            setIsOpen(true);
          }
        }
      })
      .catch(err => {
        // Silently fail - don't block the app if announcement service is down
        console.warn("[Announcement] Failed to fetch announcement", err);
      });
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    if (announcement) {
      localStorage.setItem('seen_announcement_id', announcement.id);
    }
  };

  if (!isOpen || !announcement) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#18181b] border border-yellow-500/20 rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-500/10 to-transparent p-4 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-3">
             <div className="p-2 bg-yellow-500/10 rounded-lg text-yellow-500">
                <Megaphone size={20} />
             </div>
             <div>
               <h3 className="text-white font-medium tracking-wide">{announcement.title || '系统公告'}</h3>
               <span className="text-[10px] text-gray-500 block mt-0.5">{new Date(announcement.date).toLocaleDateString()}</span>
             </div>
          </div>
          <button 
            onClick={handleClose}
            className="text-gray-400 hover:text-white transition-colors p-1 hover:bg-white/10 rounded-lg"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
           <div className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
             {announcement.content}
           </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-white/2 border-t border-white/5 flex justify-end">
           <button
             onClick={handleClose}
             className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs rounded-lg transition-colors font-medium border border-white/10"
           >
             我知道了
           </button>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementPopup;
