import React from 'react';
import { useSelectionStore } from '../src/store/selectionStore';
import { Sparkles, MonitorPlay } from 'lucide-react';
import ModelSelector from './ModelSelector';

// Branding Icons for Video Models
const GoogleLogo = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" className="inline-block">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.84z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

const OpenAILogo = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" className="inline-block text-white" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z"/>
  </svg>
);

export const VideoFormConfig: React.FC = () => {
  const {
    videoModel, setVideoModel,
    videoAspectRatio, setVideoAspectRatio,
    videoDuration, setVideoDuration,
    videoHd, setVideoHd
  } = useSelectionStore();

  // Handle auto-switch if active model is disabled
  React.useEffect(() => {
    if (videoModel.startsWith('sora-2')) {
      setVideoModel('grok-video-3');
      setVideoDuration('5');
      setVideoAspectRatio('1:1');
      setVideoHd(false);
    }
  }, [videoModel, setVideoModel, setVideoDuration, setVideoAspectRatio, setVideoHd]);

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="block text-[10px] text-gray-500 mb-1">比例</label>
          <select value={videoAspectRatio} onChange={(e) => setVideoAspectRatio(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-2 text-xs text-white">
            {videoModel.startsWith('grok') ? (
              <>
                <option value="16:9">16:9 (横屏)</option>
                <option value="9:16">9:16 (竖屏)</option>
                <option value="2:3">2:3</option>
                <option value="3:2">3:2</option>
                <option value="1:1">1:1</option>
              </>
            ) : (
              <>
                <option value="16:9">16:9 (横屏)</option>
                <option value="9:16">9:16 (竖屏)</option>
              </>
            )}
          </select>
        </div>
        <div>
          <label className="block text-[10px] text-gray-500 mb-1">时长 (秒)</label>
          <select value={videoDuration} onChange={(e) => setVideoDuration(e.target.value)} className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-2 text-xs text-white">
            {videoModel.startsWith('grok') ? (
              <>
                <option value="5">5s</option>
                <option value="10">10s</option>
                <option value="15">15s</option>
              </>
            ) : videoModel.startsWith('veo') ? (
              <>
                <option value="4">4s</option>
                <option value="6">6s</option>
                <option value="8">8s</option>
              </>
            ) : (
              <>
                <option value="10">10s</option>
                <option value="15">15s</option>
                {videoModel === 'sora-2-pro' && <option value="25">25s (Pro)</option>}
              </>
            )}
          </select>
        </div>
      </div>

      {/* Model and HD Toggle */}
      <div>
        <div className="flex items-center justify-between mb-1">
           <label className="block text-[10px] text-gray-500">视频模型</label>
           {(videoModel === 'sora-2-pro' || videoModel.startsWith('grok')) && (
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={videoHd}
                  onChange={(e) => setVideoHd(e.target.checked)}
                  className="w-3 h-3 rounded bg-gray-700 border-gray-600 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-[10px] text-purple-300 font-medium">
                  {videoModel.startsWith('grok') ? '1080P 高清' : '开启高清 (HD)'}
                </span>
              </label>
           )}
        </div>

        <ModelSelector
          dropUp
          value={videoModel}
          onChange={(val) => {
            setVideoModel(val);
            // Auto-set duration based on model family
            if (val.startsWith('grok')) {
              setVideoDuration('5');
              setVideoAspectRatio('1:1');
              setVideoHd(false);
            } else if (val.startsWith('veo')) {
              setVideoDuration('4');
              if (videoAspectRatio !== '16:9' && videoAspectRatio !== '9:16') setVideoAspectRatio('16:9');
              setVideoHd(false);
            } else {
              setVideoDuration('10');
              if (videoAspectRatio !== '16:9' && videoAspectRatio !== '9:16') setVideoAspectRatio('16:9');
              if (val !== 'sora-2-pro') setVideoHd(false);
            }
          }}
          options={[
            { value: "veo3.1-fast", label: "Veo 3.1 Fast", cost: 5, icon: <GoogleLogo /> },
            { value: "veo3.1-components", label: "Veo 3.1 Components", cost: 7.5, icon: <GoogleLogo /> },
            { value: "grok-video-3", label: "Grok Video 3", cost: 12.5, icon: <Sparkles size={14} /> },
            { value: "veo3.1-4k", label: "Veo 3.1 4K", cost: 50, icon: <GoogleLogo /> },
            { value: "veo3.1-pro-4k", label: "Veo 3.1 Pro 4K", cost: 50, icon: <GoogleLogo /> },
            { value: "veo3.1-components-4k", label: "Veo 3.1 Components 4K", cost: 50, icon: <GoogleLogo /> },
            { value: "sora-2", label: "Sora-2", cost: 12.5, icon: <OpenAILogo />, disabled: true, disabledReason: "由于官方限制，暂停使用" },
            { value: "sora-2-pro", label: "Sora-2 Pro", cost: 62.5, icon: <OpenAILogo />, disabled: true, disabledReason: "由于官方限制，暂停使用" }
          ]}
        />
      </div>
    </div>
  );
};

export default VideoFormConfig;
