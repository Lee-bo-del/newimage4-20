import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

interface DropUpOption {
  value: string;
  label: string;
}

interface DropUpSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: DropUpOption[];
  className?: string;
}

const DropUpSelect: React.FC<DropUpSelectProps> = ({ value, onChange, options, className = "" }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find(opt => opt.value === value) || options[0];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={`relative ${className}`} ref={containerRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-gray-800 border border-gray-700 rounded px-2 py-2 text-xs text-white flex items-center justify-between hover:bg-gray-750 transition-colors"
      >
        <span className="truncate">{selectedOption?.label}</span>
        <ChevronDown size={12} className={`text-gray-400 transition-transform duration-200 ml-1 shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute bottom-full mb-1 left-0 w-full bg-[#1A1A1A] border border-gray-700 rounded-lg shadow-xl overflow-hidden z-50 max-h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600">
          {options.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => {
                onChange(option.value);
                setIsOpen(false);
              }}
              className={`w-full text-left px-3 py-1.5 text-xs transition-colors ${
                value === option.value
                  ? 'bg-purple-500/10 text-purple-200'
                  : 'text-gray-300 hover:bg-gray-700/50'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default DropUpSelect;
