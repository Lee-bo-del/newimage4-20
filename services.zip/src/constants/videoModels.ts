
export const VIDEO_LOSS_CONFIG = {
  'sora-2': { max: 1, labels: [] },
  'sora-2-pro': { max: 1, labels: [] },
  'veo3.1-fast': { max: 2, labels: ['首帧', '尾帧'] },
  'veo3.1-4k': { max: 2, labels: ['首帧', '尾帧'] },
  'veo3.1-pro-4k': { max: 2, labels: ['首帧', '尾帧'] },
  'veo3.1-components': { max: 3, labels: [] },
  'veo3.1-components-4k': { max: 3, labels: [] },
  'grok-video-3': { max: 1, labels: [] },
} as const;

export const VIDEO_COSTS: Record<string, number> = {
  'sora-2': 12.5,
  'sora-2-pro': 62.5,
  'veo3.1-4k': 12.5,
  'veo3.1-fast': 5,
  'veo3.1-pro-4k': 50,
  'veo3.1-components-4k': 12.5,
  'veo3.1-components': 7.5,
  'grok-video-3': 12.5
};
