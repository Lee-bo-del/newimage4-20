import React from 'react';
import { useSelectionStore } from '../src/store/selectionStore';
import { useCanvasStore } from '../src/store/canvasStore';
import { ToolMode, NodeData } from '../types';
import { Layers, Zap, Sparkles, Banana, Eraser, Trash2 } from 'lucide-react';
import DropUpSelect from './DropUpSelect';
import ModelSelector from './ModelSelector';

export const ImageFormConfig: React.FC = () => {
  const {
    aspectRatio, setAspectRatio,
    customRatio, setCustomRatio,
    imageSize, setImageSize,
    quantity, setQuantity,
    imageModel, setImageModel,
    imageLine, setImageLine,
    selectedIds, toolMode, setToolMode
  } = useSelectionStore();

  const { nodes, updateNode } = useCanvasStore();
  const selectedNode = nodes.find((n: NodeData) => n.id === selectedIds[0]);
  const hasStrokes = selectedNode?.maskStrokes && selectedNode.maskStrokes.length > 0;

  const ratioOptions = [
    { label: '智能', value: 'Smart' },
    { label: '自定义', value: 'Custom' },
    { label: '1:1', value: '1:1' },
    { label: '16:9', value: '16:9' },
    { label: '9:16', value: '9:16' },
    { label: '4:3', value: '4:3' },
    { label: '3:4', value: '3:4' },
    { label: '3:2', value: '3:2' },
    { label: '2:3', value: '2:3' },
    { label: '21:9', value: '21:9' },
    { label: '9:21', value: '9:21' },
    { label: '5:4', value: '5:4' }
  ];

  return (
    <>
      <div className="mb-2">
        <label className="block text-[10px] text-gray-500 mb-1">生图模型</label>
        <ModelSelector
          dropUp
          value={imageModel}
          onChange={(val) => setImageModel(val)}
          options={[
            { 
              value: "nano-banana", 
              label: "Nano Banana Pro", 
              cost: 5, 
              icon: (
                <div className="flex items-center gap-0.5">
                  <Banana size={12} className="text-yellow-400" />
                  <Banana size={12} className="text-yellow-400" />
                </div>
              )
            },
            { 
              value: "gemini-flash", 
              label: "Nano Banana 2", 
              cost: 2.5, 
              icon: (
                <div className="flex items-center gap-0.5">
                  <Banana size={12} className="text-yellow-400" />
                  <Zap size={12} className="text-yellow-400" />
                </div>
              )
            },
            { 
              value: "grok-4.2-image", 
              label: "Grok 4.2 Image", 
              cost: 3, 
              icon: <Sparkles size={12} className="text-yellow-400" />
            },
            { 
              value: "grok-4.1-image", 
              label: "Grok 4.1 Image", 
              cost: 2, 
              icon: <Sparkles size={12} className="text-orange-400" />
            },
            { 
              value: "doubao-seedream-5-0-260128", 
              label: "即梦5.0", 
              cost: 3.75, 
              icon: <Sparkles size={12} className="text-purple-400" />
            },
            { 
              value: "doubao-seedream-4-5-251128", 
              label: "即梦4.5", 
              cost: 3.75, 
              icon: <Layers size={12} className="text-blue-400" />
            },
            { 
              value: "z-image-turbo", 
              label: "Z-image -turbo", 
              cost: 1.75, 
              icon: <Zap size={12} className="text-blue-400" />
            }
          ]}
        />
      </div>

      <div className={`grid ${imageModel === 'z-image-turbo' ? 'grid-cols-2' : 'grid-cols-3'} gap-2`}>
        <div>
          <label className="block text-[10px] text-gray-500 mb-1">比例</label>
          <DropUpSelect
            value={aspectRatio}
            onChange={(val) => setAspectRatio(val)}
            options={[
              ...ratioOptions,
              ...(imageModel === 'gemini-flash' ? [
                { value: '4:1', label: '4:1' },
                { value: '1:4', label: '1:4' },
                { value: '8:1', label: '8:1' },
                { value: '1:8', label: '1:8' },
              ] : [])
            ]}
          />
            {aspectRatio === 'Custom' && (
            <div className="flex items-center gap-1 mt-1">
                <input
                  type="text"
                  value={customRatio}
                  onChange={(e) => setCustomRatio(e.target.value)}
                  placeholder="16:9"
                  className="w-full bg-gray-900 border border-gray-700 rounded px-1 py-1 text-[10px] text-white"
                />
            </div>
            )}
        </div>
        {imageModel !== 'z-image-turbo' && !imageModel.startsWith('grok') && (
        <div>
          <label className="block text-[10px] text-gray-500 mb-1">尺寸</label>
          <DropUpSelect
            value={imageSize}
            onChange={(val) => setImageSize(val)}
            options={
              imageModel.includes('5-0')
                ? [{ value: '2k', label: '2K' }, { value: '3k', label: '3K' }]
                : imageModel.includes('4-5')
                  ? [{ value: '2k', label: '2K' }, { value: '4k', label: '4K' }]
                  : [{ value: '1k', label: '1K' }, { value: '2k', label: '2K' }, { value: '4k', label: '4K' }]
            }
          />
        </div>
        )}
        {imageModel === 'grok-4.2-image' && (
        <div>
          <label className="block text-[10px] text-gray-500 mb-1">线路</label>
          <DropUpSelect
            value={imageLine}
            onChange={(val) => setImageLine(val)}
            options={[
              { value: 'line1', label: '线路一' },
              { value: 'line2', label: '线路二' },
            ]}
          />
        </div>
        )}
        <div>
          <label className="block text-[10px] text-gray-500 mb-1">数量</label>
          <DropUpSelect
            value={String(quantity)}
            onChange={(val) => setQuantity(parseInt(val))}
            options={[
              { value: '1', label: '1' },
              { value: '2', label: '2' },
              { value: '4', label: '4' },
            ]}
          />
        </div>
      </div>
    </>
  );
};

export default ImageFormConfig;
