import React, { useState, useCallback, useRef } from 'react';
import { Upload, Loader2, Copy, ScanSearch, Check, Sparkles as SparklesIcon } from 'lucide-react';
import { reversePrompt } from '../services/reversePromptService';
import GlassModal from './GlassModal';

interface ReversePromptModalProps {
    isOpen: boolean;
    onClose: () => void;
    onUsePrompt?: (prompt: string) => void;
}

const ReversePromptModal: React.FC<ReversePromptModalProps> = ({ isOpen, onClose, onUsePrompt }) => {
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [preview, setPreview] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<string>('');
    const [error, setError] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFile = useCallback((file: File) => {
        if (!file.type.startsWith('image/')) {
            setError('请上传有效的图片文件');
            return;
        }
        setImageFile(file);
        setError(null);
        setResult('');

        // Create preview
        const reader = new FileReader();
        reader.onload = (e) => setPreview(e.target?.result as string);
        reader.readAsDataURL(file);
    }, []);

    const handleDrop = useCallback((e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            handleFile(e.dataTransfer.files[0]);
        }
    }, [handleFile]);

    const handleAnalyze = async () => {
        if (!imageFile) return;

        setLoading(true);
        setError(null);

        try {
            const apiKey = localStorage.getItem('gemini_api_key') || '';
            if (!apiKey) {
                throw new Error('请先在设置中配置 API Key');
            }

            const prompt = await reversePrompt(apiKey, imageFile);
            setResult(prompt);
        } catch (err: any) {
            setError(err.message || '分析失败，请重试');
        } finally {
            setLoading(false);
        }
    };

    const handleCopy = () => {
        if (!result) return;
        navigator.clipboard.writeText(result);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const handleClose = () => {
        setImageFile(null);
        setPreview(null);
        setResult('');
        setError(null);
        onClose();
    };

    return (
        <GlassModal
            isOpen={isOpen}
            onClose={handleClose}
            title="图片逆推提示词"
            width="max-w-lg"
        >
            <div className="flex flex-col h-full space-y-6 pt-2">
                {/* Description */}
                <div className="px-1 text-sm text-gray-400">
                    上传图片，AI 将自动分析画面内容并生成 detailed prompt。
                </div>

                {/* Upload Area */}
                <div className="space-y-2">
                    {!preview ? (
                        <div
                            className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${error ? 'border-red-500/50 bg-red-900/10' : 'border-white/10 hover:border-blue-500/50 hover:bg-white/5'
                                }`}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={handleDrop}
                            onClick={() => fileInputRef.current?.click()}
                        >
                            <div className="p-4 bg-white/5 rounded-full mb-4 ring-1 ring-white/10">
                                <Upload className="text-blue-400" size={32} />
                            </div>
                            <h3 className="text-gray-200 font-medium mb-1">点击或拖拽上传图片</h3>
                            <p className="text-gray-500 text-sm">支持 JPG, PNG, WEBP</p>
                            <input
                                type="file"
                                ref={fileInputRef}
                                onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
                                className="hidden"
                                accept="image/*"
                            />
                        </div>
                    ) : (
                        <div className="relative group rounded-xl overflow-hidden bg-black/50 border border-white/10 max-h-[300px] flex items-center justify-center shadow-lg">
                            <img src={preview} alt="Preview" className="max-w-full max-h-[300px] object-contain" />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 backdrop-blur-sm">
                                <button
                                    onClick={() => fileInputRef.current?.click()}
                                    className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg backdrop-blur-md transition-colors border border-white/10"
                                >
                                    更换图片
                                </button>
                                {loading && (
                                    <div className="text-white flex items-center gap-2">
                                        <Loader2 className="animate-spin" /> 分析中...
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {error && (
                        <div className="text-red-400 text-sm px-2 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                            {error}
                        </div>
                    )}
                </div>

                {/* Action Button */}
                {preview && !result && !loading && (
                    <button
                        onClick={handleAnalyze}
                        className="w-full py-3 bg-linear-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl font-medium transition-all shadow-lg shadow-blue-900/20 active:scale-[0.98] flex items-center justify-center gap-2"
                    >
                        <ScanSearch size={18} />
                        开始全方位分析 (消耗 0.5 金币)
                    </button>
                )}

                {/* Loading State */}
                {loading && (
                    <div className="py-8 text-center space-y-4 rounded-xl bg-white/5 border border-white/5">
                        <Loader2 className="animate-spin w-8 h-8 text-blue-500 mx-auto" />
                        <p className="text-gray-400 animate-pulse text-sm">正在像资深设计师一样分析图片细节...</p>
                    </div>
                )}

                {/* Result Area */}
                {result && (
                    <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-500 flex-1 flex flex-col min-h-0">
                        <div className="flex items-center justify-between px-1">
                            <h3 className="text-gray-200 font-medium flex items-center gap-2 text-sm">
                                <SparklesIcon className="text-yellow-500" size={16} /> 分析结果
                            </h3>
                            <div className="flex gap-2">
                                <button
                                    onClick={handleCopy}
                                    className="text-xs flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-white/5 hover:bg-white/10 text-gray-300 transition-colors border border-white/5"
                                >
                                    {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                                    {copied ? '已复制' : '复制'}
                                </button>
                                {onUsePrompt && (
                                    <button
                                        onClick={() => {
                                            onUsePrompt(result);
                                            onClose();
                                        }}
                                        className="text-xs px-2.5 py-1.5 rounded-md bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 transition-colors"
                                    >
                                        使用此提示词
                                    </button>
                                )}
                            </div>
                        </div>

                        <div className="bg-black/30 border border-white/10 rounded-xl p-4 relative group flex-1 overflow-y-auto custom-scrollbar shadow-inner">
                            <p className="text-gray-300 leading-relaxed text-sm whitespace-pre-wrap font-mono">{result}</p>
                        </div>
                    </div>
                )}
            </div>
        </GlassModal>
    );
};

export default ReversePromptModal;
