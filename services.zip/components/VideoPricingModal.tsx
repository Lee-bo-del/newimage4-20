import React from 'react';
import { X } from 'lucide-react';

interface VideoPricingModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const VideoPricingModal: React.FC<VideoPricingModalProps> = ({ isOpen, onClose }) => {
    return !isOpen ? null : (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
            <div
                className="bg-gray-900 border border-gray-700 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in duration-200"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-900/50">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <span className="text-purple-400">📹</span> 视频生成计费及使用说明
                    </h3>
                    <button
                        onClick={onClose}
                        className="text-gray-400 hover:text-white transition-colors p-1 hover:bg-gray-800 rounded-lg"
                    >
                        <X size={20} />
                    </button>
                </div>

                <div className="p-6 space-y-6 text-sm text-gray-300 max-h-[80vh] overflow-y-auto">

                    {/* Sora Section */}
                    <div className="space-y-3">
                        <h4 className="font-bold text-green-400 text-base border-b border-gray-800 pb-2">Sora 系列</h4>
                        <div className="grid grid-cols-1 gap-3">
                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-green-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">sora-2</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 10s / 15s，不支持 HD 模式</div>
                                </div>
                                <div className="text-green-400 font-mono font-bold whitespace-nowrap">4 分/次</div>
                            </div>

                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-green-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">sora-2-pro</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 10s / 15s / 25s，支持 HD 模式</div>
                                </div>
                                <div className="text-green-400 font-mono font-bold whitespace-nowrap">100 分/次</div>
                            </div>
                        </div>
                    </div>

                    {/* Grok Section */}
                    <div className="space-y-3">
                        <h4 className="font-bold text-purple-400 text-base border-b border-gray-800 pb-2">Grok 系列</h4>
                        <div className="grid grid-cols-1 gap-3">
                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-purple-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">grok-video-3</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 5s / 10s，支持 HD 和参考图</div>
                                </div>
                                <div className="text-purple-400 font-mono font-bold whitespace-nowrap">12.5 分/次</div>
                            </div>
                        </div>
                    </div>

                    {/* Veo Section */}
                    <div className="space-y-3">
                        <h4 className="font-bold text-blue-400 text-base border-b border-gray-800 pb-2">Veo 3.1 系列</h4>
                        <div className="grid grid-cols-1 gap-3">
                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-blue-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">veo3.1-fast</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 8s，支持首尾帧 (图1=首, 图2=尾)</div>
                                </div>
                                <div className="text-blue-400 font-mono font-bold whitespace-nowrap">8 分/次</div>
                            </div>

                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-blue-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">veo3.1-4k</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 8s，支持首尾帧 (图1=首, 图2=尾)</div>
                                </div>
                                <div className="text-blue-400 font-mono font-bold whitespace-nowrap">20 分/次</div>
                            </div>

                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-blue-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">veo3.1-pro-4k</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 8s，支持首尾帧 (图1=首, 图2=尾)</div>
                                </div>
                                <div className="text-blue-400 font-mono font-bold whitespace-nowrap">80 分/次</div>
                            </div>

                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-blue-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">veo3.1-components</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 8s，仅首帧，支持多图融合 (1-3张)</div>
                                </div>
                                <div className="text-blue-400 font-mono font-bold whitespace-nowrap">12 分/次</div>
                            </div>

                            <div className="flex justify-between items-center bg-gray-800/50 p-3 rounded-lg border border-gray-800 hover:border-blue-500/30 transition-colors">
                                <div>
                                    <div className="font-bold text-white">veo3.1-components-4k</div>
                                    <div className="text-xs text-gray-400 mt-1">时长 8s，仅首帧，支持多图融合 (1-3张)</div>
                                </div>
                                <div className="text-blue-400 font-mono font-bold whitespace-nowrap">20 分/次</div>
                            </div>
                        </div>
                    </div>

                </div>
                <div className="p-4 bg-gray-900/80 border-t border-gray-800 text-center text-xs text-gray-500">
                    点击遮罩层或右上角关闭
                </div>
            </div>
        </div>
    );
};

export default VideoPricingModal;
