import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AppStatus, NodeData, ToolMode } from '../types';
import { useSelectionStore } from '../src/store/selectionStore';
import { useCanvasStore } from '../src/store/canvasStore';
import { generateImageApi, getModelBySize, generateGeminiImage, editImageApi } from '../services/api'; // Use new API
import { generateVideo } from '../services/videoService';
import { assetStorage } from '../src/services/assetStorage';
import { optimizePrompt, PromptOption } from '../services/promptService';
import { useHistoryStore } from '../src/store/historyStore';
import { Wand2, Loader2, ImagePlus, Layers, X, Upload, Plus, GripVertical, Move, Sparkles, Minus, Maximize2, Banana, ChevronLeft, ChevronRight, Check, Clapperboard, Film, HelpCircle, LayoutGrid, MonitorPlay, Zap, Pin, PinOff, Eraser, Trash2 } from 'lucide-react';
import VideoPricingModal from './VideoPricingModal';
import CoinIcon from './CoinIcon';
import ModelSelector from './ModelSelector';
import ImageFormConfig from './ImageFormConfig';
import VideoFormConfig from './VideoFormConfig';
import { GoogleLogo, OpenAILogo } from './Logos';
import { DOUBAO_RESOLUTIONS, getDoubaoSize, findClosestRatio, extractRatioFromPrompt, renderMaskToDataURL, getBase64FromUrl } from '../src/utils/imageUtils';

// Branding Icons are now in Logos.tsx

import { VIDEO_LOSS_CONFIG, VIDEO_COSTS } from '../src/constants/videoModels';
import logo from '../src/assets/logo.svg';

interface ControlPanelProps {
  onInitGenerations: (count: number, prompt: string, aspectRatio?: string, baseNode?: NodeData, type?: 'IMAGE' | 'VIDEO') => string[];
  onUpdateGeneration: (id: string, src: string | null, error?: string, taskId?: string) => void;
  onUpdateProgress?: (id: string, progress: number) => void;
  onOpenBatchModal: () => void;
}

interface DragState {
  isDragging: boolean;
  position: { x: number; y: number };
  offset: { x: number; y: number };
}

const ControlPanel: React.FC<ControlPanelProps> = React.memo(({ onInitGenerations, onUpdateGeneration, onUpdateProgress, onOpenBatchModal }) => {
  const { 
    toolMode, 
    setToolMode, 
    selectedIds, 
    status, 
    setStatus,
    referenceImages, 
    addReferenceImage, 
    addReferenceImages,
    removeReferenceImage, 
    clearReferenceImages,
    pendingPrompt, 
    setPendingPrompt, 
    isControlPanelOpen, 
    setControlPanelOpen, 
    panelMode, 
    setPanelMode,
    videoModel,
    setVideoModel,
    lightboxImage,
    closeLightbox,
    apiKey,
    setApiKey,
    setReferenceImages,
    // Persistent Inputs
    prompt, setPrompt,
    aspectRatio, setAspectRatio,
    customRatio, setCustomRatio,
    imageSize, setImageSize,
    quantity, setQuantity,
    videoAspectRatio, setVideoAspectRatio,
    videoDuration, setVideoDuration,
    videoHd, setVideoHd,
    imageModel, setImageModel,
    imageLine, setImageLine,
    thinkingLevel, setThinkingLevel,
    brushSize, setBrushSize,
    brushColor, setBrushColor
  } = useSelectionStore();

  // Auto-clear error when switching modes or models
  useEffect(() => {
    if (error) setError(null);
  }, [panelMode, videoModel, imageModel]);

  // Optimize: only listen to nodes list, ignore canvasState (pan/zoom)
  const { nodes, updateNode } = useCanvasStore();
  const { addLog } = useHistoryStore();
  const selectedNodes = nodes.filter(n => selectedIds.includes(n.id) && (n.type === 'IMAGE' || n.type === 'VIDEO'));

  // 所有状态定义
  // const [prompt, setPrompt] = useState(''); // Moved to store
  const [error, setError] = useState<string | null>(null);

  // const [aspectRatio, setAspectRatio] = useState('Smart'); // Moved to store
  // const [customRatio, setCustomRatio] = useState(''); // Moved to store
  // const [imageSize, setImageSize] = useState('1k'); // Moved to store
  // const [videoModel, setVideoModel] = useState<string>('veo3.1-fast'); // Moved to store
  // const [videoAspectRatio, setVideoAspectRatio] = useState<string>('16:9'); // Moved to store
  // const [videoDuration, setVideoDuration] = useState<string>('4'); // Moved to store
  // const [videoHd, setVideoHd] = useState(false); // Moved to store
  // const [quantity, setQuantity] = useState(1); // Moved to store
  
  const [draggingIndex, setDraggingIndex] = useState<number | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [panelMinimized, setPanelMinimized] = useState(false);
  const [panelVisible, setPanelVisible] = useState(true);
  const [showPricingModal, setShowPricingModal] = useState(false);

  // Auto-collapse states
  const [isHovered, setIsHovered] = useState(false);
  const [autoCollapsed, setAutoCollapsed] = useState(false);
  const [isPinned, setIsPinned] = useState(true);
  const hoverTimerRef = useRef<NodeJS.Timeout | null>(null);

  // 提示词方案选择相关状态
  const [promptOptions, setPromptOptions] = useState<PromptOption[]>([]);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState(0);
  const [showOptionsPanel, setShowOptionsPanel] = useState(false);

  const panelFileInputRef = useRef<HTMLInputElement>(null);

  const isGenerateMode = toolMode === ToolMode.GENERATE;
  // Use persistent panelMode instead of transient toolMode
  const isVideoMode = panelMode === 'VIDEO';

  const isImg2ImgMode = !isGenerateMode && !isVideoMode && selectedNodes.length > 0;
  const primaryNode = selectedNodes.length > 0 ? selectedNodes[0] : null;

  // Sync panel mode when selecting nodes - REMOVED to prevent unwanted switching
  // User wants "Sticky" behavior: If I am in Video Mode, clicking an image should NOT switch me to Image Mode.
  // The mode should only change when explicitly requested (e.g. via Toolbar) or maybe when strictly selecting a Video node if we weren't already.
  // For now, removing this entirely gives maximum stability.
  /*
  useEffect(() => {
    if (primaryNode) {
        if (primaryNode.type === 'VIDEO' && panelMode !== 'VIDEO') {
            setPanelMode('VIDEO');
        } else if (primaryNode.type === 'IMAGE' && panelMode !== 'IMAGE') {
            setPanelMode('IMAGE');
        }
    }
  }, [primaryNode, panelMode, setPanelMode]);
  */
  const isMultiSelect = selectedNodes.length > 1;
  const isGenerating = status === AppStatus.LOADING;



  useEffect(() => {
    if (isImg2ImgMode && primaryNode) setPrompt(primaryNode.prompt || '');
  }, [primaryNode, isImg2ImgMode]);

  // Clear reference images when switching modes (e.g. from Image to Video)
  // FIXED: If persistence is desired, maybe we SHOULD NOT clear reference images on mode switch?
  // User asked for "input reference images... disappear on refresh".
  // But if I switch mode, clearing might still be desired as contexts differ.
  // However, persistence across refresh means we shouldn't clear on mount.
  // This useEffect runs when panelMode changes.
  useEffect(() => {
    // Only clear if the list is invalid for the new mode?
    // Or just let user decide. 
    // For now, let's DISABLE auto-clear on mode switch to make it more "persistent" feel if user accidentally switches.
    // Or keep it? User specifically asked about page refresh.
    // Let's keep it but maybe only if empty?
    // Actually, comment it out for now to test "maximum persistence"
    // setReferenceImages([]);
  }, [panelMode, setReferenceImages]);

  useEffect(() => {
    if (pendingPrompt) {
        // Delay setting prompt to ensure UI is ready and overrides other effects
        const t = setTimeout(() => {
            setPrompt(pendingPrompt);
            setPendingPrompt(null);
        }, 50);
        return () => clearTimeout(t);
    }
  }, [pendingPrompt, setPendingPrompt]);

  // 拖拽相关 Refs - UNIFIED POSITIONING
  const panelRef = useRef<HTMLDivElement>(null);
  const posRef = useRef({ x: 20, y: 80 });

  const dragStartPos = useRef({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);

  const updatePanelTransform = (x: number, y: number) => {
    if (panelRef.current) {
      panelRef.current.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    }
  };

  // 仅在组件挂载时初始化位置，根据需求靠上靠左靠齐
  useEffect(() => {
    const initialX = 20; // 紧贴左侧边距
    const initialY = 20; // 紧贴上方边距
    
    posRef.current = { x: initialX, y: initialY };
    updatePanelTransform(posRef.current.x, posRef.current.y);
  }, []);

  const handleDragStart = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragStartPos.current = {
      x: e.clientX - posRef.current.x,
      y: e.clientY - posRef.current.y
    };

    // 增加全局样式防止拖拽时文本被选中
    document.body.style.userSelect = 'none';
  }, []);

  const handleDragMove = useCallback((e: MouseEvent) => {
    // 这里的逻辑直接跑在原生事件循环下，不触发 React 渲染
    const panel = panelRef.current;
    if (!panel) return;

    let newX = e.clientX - dragStartPos.current.x;
    let newY = e.clientY - dragStartPos.current.y;

    // 边界限制
    const maxX = window.innerWidth - panel.offsetWidth - 10;
    const maxY = window.innerHeight - panel.offsetHeight - 10;
    newX = Math.max(10, Math.min(newX, maxX));
    newY = Math.max(10, Math.min(newY, maxY));

    posRef.current = { x: newX, y: newY };
    updatePanelTransform(newX, newY);
  }, []);

  const handleDragEnd = useCallback(() => {
    setIsDragging(false);
    document.body.style.userSelect = '';
  }, []);

  // Touch handlers for mobile drag
  const handleTouchMove = useCallback((e: TouchEvent) => {
    const panel = panelRef.current;
    if (!panel) return;

    if (e.cancelable) e.preventDefault(); // Prevent scrolling while dragging panel

    const touch = e.touches[0];
    let newX = touch.clientX - dragStartPos.current.x;
    let newY = touch.clientY - dragStartPos.current.y;

    const maxX = window.innerWidth - panel.offsetWidth - 10;
    const maxY = window.innerHeight - panel.offsetHeight - 10;
    
    // On Mobile, we might want to constrain to Y axis only if it's a bottom sheet?
    // user said "Canvas or Video window cannot be dragged", implying they want to move it.
    // Let's allow free drag but keep bounds.
    
    newX = Math.max(10, Math.min(newX, maxX));
    newY = Math.max(10, Math.min(newY, maxY));

    posRef.current = { x: newX, y: newY };
    updatePanelTransform(newX, newY);
  }, []);

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false);
    document.body.style.overflow = ''; // Restore scrolling
  }, []);

  const handleTouchStartRaw = useCallback((e: React.TouchEvent) => {
    // e.preventDefault(); // Do not prevent default here immediately or clicks fail, but for a drag handle it's fine
    setIsDragging(true);
    const touch = e.touches[0];
    dragStartPos.current = {
      x: touch.clientX - posRef.current.x,
      y: touch.clientY - posRef.current.y
    };
    document.body.style.overflow = 'hidden'; // Lock scrolling
  }, []);


  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleDragMove, { passive: true });
      window.addEventListener('mouseup', handleDragEnd);
      
      // Add non-passive listener for touch move to prevent scroll
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      window.addEventListener('touchend', handleTouchEnd);
      
      return () => {
        window.removeEventListener('mousemove', handleDragMove);
        window.removeEventListener('mouseup', handleDragEnd);
        window.removeEventListener('touchmove', handleTouchMove);
        window.removeEventListener('touchend', handleTouchEnd);
      };
    }
  }, [isDragging, handleDragMove, handleDragEnd, handleTouchMove, handleTouchEnd]);

  // findClosestRatio and extractRatioFromPrompt moved to imageUtils.ts

  const createCollageFromSrcs = async (srcs: string[]): Promise<string> => {
    if (srcs.length === 0) return '';
    // Removed short-circuit: Always convert to base64 via canvas to ensure valid data payload
    // if (srcs.length === 1) return srcs[0];
    return new Promise((resolve, reject) => {
      const loadedImages: HTMLImageElement[] = [];
      let loadedCount = 0;
      let hasError = false;
      srcs.forEach(src => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          if (hasError) return;
          loadedCount++;
          if (loadedCount === srcs.length) renderCollage();
        };
        img.onerror = () => { hasError = true; reject(new Error("加载参考图失败")); };
        img.src = src;
        loadedImages.push(img);
      });
      const renderCollage = () => {
        const gap = 10;
        let maxHeight = 0;
        loadedImages.forEach(img => { maxHeight = Math.max(maxHeight, img.height); });
        const scale = maxHeight > 1024 ? 1024 / maxHeight : 1;
        let scaledTotalWidth = 0;
        loadedImages.forEach(img => { scaledTotalWidth += (img.width * scale) + gap; });
        const canvas = document.createElement('canvas');
        canvas.width = scaledTotalWidth - gap;
        canvas.height = maxHeight * scale;
        const ctx = canvas.getContext('2d');
        if (!ctx) { reject(new Error("Canvas 创建失败")); return; }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        let currentX = 0;
        loadedImages.forEach(img => {
          const w = img.width * scale;
          ctx.drawImage(img, currentX, 0, w, img.height * scale);
          currentX += w + gap;
        });
        resolve(canvas.toDataURL('image/jpeg', 0.9));
      };
    });
  };

  const handleRefDragStart = (e: React.DragEvent, index: number) => {
    setDraggingIndex(index);
    e.dataTransfer.setData('application/x-sort-index', index.toString());
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleRefDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    e.stopPropagation();
    const sourceIndexStr = e.dataTransfer.getData('application/x-sort-index');
    if (sourceIndexStr) {
      const sourceIndex = parseInt(sourceIndexStr);
      if (!isNaN(sourceIndex) && sourceIndex !== targetIndex) {
        const newArr = [...referenceImages];
        const [moved] = newArr.splice(sourceIndex, 1);
        newArr.splice(targetIndex, 0, moved);
        setReferenceImages(newArr);
      }
    }
    setDraggingIndex(null);
  };

  const handlePanelDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.types.includes('application/x-sort-index')) return;

    const max = isVideoMode ? (VIDEO_LOSS_CONFIG[videoModel as keyof typeof VIDEO_LOSS_CONFIG]?.max || 1) : 10;
    
    // DEBUG ALERT
    // alert(`[Debug] Drop: Max=${max}, Current=${referenceImages.length}, IsVideo=${isVideoMode}, Model=${videoModel}`);

    // We still check remaining slots for immediate UI feedback, 
    // but the store action will be the final gatekeeper.
    const remainingSlots = max - referenceImages.length;
    if (remainingSlots <= 0) {
       setError(`最多只能上传 ${max} 张参考图`);
       return;
    }

    const newImages: Array<{src: string, blob?: Blob}> = [];

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
      
      if (files.length > remainingSlots) {
        setError(`当前模型限制 ${max} 张参考图,您选择了 ${files.length} 张`);
        // We can either return or take the first N. Let's return to match previous behavior (fail fast).
        return; 
      }

      // Create blob URLs with File objects
      for (const file of files) {
        if (file.size > 10 * 1024 * 1024) {
          console.warn('File too large:', file.name);
          continue;
        }
        
        // Create blob URL for display
        const blobUrl = URL.createObjectURL(file);
        newImages.push({ src: blobUrl, blob: file });
      }
    } else {
      // Handle HTML/URI drops
      const html = e.dataTransfer.getData('text/html');
      if (html) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        doc.querySelectorAll('img').forEach((img, idx) => {
          if (img.src && !img.src.startsWith('blob:')) newImages.push({ src: img.src });
        });
      } else {
        const uri = e.dataTransfer.getData('text/uri-list');
        if (uri) {
           uri.split('\n')
              .filter(u => u.trim() && !u.startsWith('#'))
              .forEach(u => newImages.push({ src: u }));
        }
      }
    }

    if (newImages.length > 0) {
       // Atomic add with limit enforcement
       useSelectionStore.getState().addReferenceImages(newImages, max);
    }
  };

  const handlePanelFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const max = isVideoMode ? (VIDEO_LOSS_CONFIG[videoModel as keyof typeof VIDEO_LOSS_CONFIG]?.max || 1) : 10;
      const remainingSlots = max - referenceImages.length;

      if (remainingSlots <= 0) {
         setError(`最多只能上传 ${max} 张参考图`);
         e.target.value = ''; // Reset
         return;
      }

      if (files.length > remainingSlots) {
         setError(`只能再上传 ${remainingSlots} 张图片 (当前限制: ${max})`);
         e.target.value = '';
         return;
      }

      const newImages: Array<{src: string, blob: Blob}> = [];
      for (const file of files) {
        if (file.size > 10 * 1024 * 1024) { 
          setError("文件过大 (最大 10MB)");
          continue;
        }
        
        // Create blob URL for display
        const blobUrl = URL.createObjectURL(file);
        newImages.push({ src: blobUrl, blob: file });
      }

      if (newImages.length > 0) {
         useSelectionStore.getState().addReferenceImages(newImages, max);
      }
      
      e.target.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Submit triggered", { prompt, apiKey });
    if (!prompt.trim()) {
      setError("请输入提示词");
      return;
    }
    if (!apiKey.trim()) {
      setError("请先在设置中输入 API Key");
      return;
    }
    setError(null);
    let effectiveRatio = aspectRatio;

    if (aspectRatio === 'Smart') {
      if (isImg2ImgMode && selectedNodes.length > 0) {
        effectiveRatio = findClosestRatio(selectedNodes[0].width / selectedNodes[0].height);
      } else if (referenceImages.length > 0) {
        effectiveRatio = '1:1';
      } else {
        effectiveRatio = extractRatioFromPrompt(prompt) || '16:9';
      }
    } else if (aspectRatio === 'Custom') {
      if (!/^\d+:\d+$/.test(customRatio)) {
        setError("自定义比例格式错误，请使用 '宽:高' 格式，且必须为英文冒号");
        return;
      }
      effectiveRatio = customRatio;
    }

    // 自动在提示词后添加比例参数供模型参考 (双重保障)
    const promptWithRatio = `${prompt.trim()} --ar ${effectiveRatio}`;
    const currentPrompt = promptWithRatio;
    // Decision Logic: 
    // User explicitly requested NO "Regenerate" / "Edit Mode".
    // Panel always functions as "Create New". References must be added manually.
    const effectiveImg2ImgMode = false; // Forced to false per user request

    // ========== 统一异步生成路径（Nano Banana / Gemini Flash）==========
    const getModelName = () => {
      if (imageModel === 'gemini-flash') return 'gemini-3.1-flash-image-preview';
      if (imageModel === 'nano-banana') return getModelBySize(imageSize);
      return imageModel; // For doubao-seedream-* and z-image-turbo
    };

    // 是否为线路二 (同步模式)
    const isSyncMode = imageModel === 'grok-4.2-image' && imageLine === 'line2';

    // 计算实际发送给API的size参数
    const getEffectiveSize = (model: string) => {
      if (model === 'z-image-turbo') {
        return getDoubaoSize(model, '1k', effectiveRatio);
      }
      if (model.startsWith('doubao')) {
        return getDoubaoSize(model, imageSize, effectiveRatio);
      }
      return imageSize.toLowerCase();
    };



    if (effectiveImg2ImgMode && selectedNodes.length > 0) {
      for (const node of selectedNodes) {
        if (!node.src) continue;
        const placeholderIds = onInitGenerations(quantity, currentPrompt, effectiveRatio, node);
        placeholderIds.forEach(pid => {
           const payload: any = {
             model: getModelBySize(imageSize),
             prompt: currentPrompt,
             size: imageSize.toLowerCase(),
             aspect_ratio: effectiveRatio,
             n: 1,
             image: node.src!.includes(',') ? node.src!.split(',')[1] : node.src
           };
           
           generateImageApi(apiKey, payload)
            .then((res: any) => {
               if (res.taskId) {
                 onUpdateGeneration(pid, null, undefined, res.taskId);
               } else if (res.data && res.data[0] && res.data[0].url) {
                 onUpdateGeneration(pid, res.data[0].url);
               } else if (res.url) {
                 onUpdateGeneration(pid, res.url);
               } else {
                 onUpdateGeneration(pid, null, "未知返回格式");
               }
            })
            .catch((err: any) => { 
              onUpdateGeneration(pid, null, err.message || "生成失败"); 
            });
        });
      }
    } else {

      if (referenceImages.length > 0) {
        // Extract srcs from ReferenceImage objects
        const refSrcs = referenceImages.map(r => r.src);
        const modelName = getModelName();
        const isDoubao = modelName.startsWith('doubao');

        const processSubmission = async (imagePayload: any, customPrompt?: string) => {
          const placeholderIds = onInitGenerations(quantity, currentPrompt, effectiveRatio);
          placeholderIds.forEach(pid => {
            const payload: any = {
                model: modelName,
                prompt: customPrompt || currentPrompt,
                size: getEffectiveSize(modelName),
                aspect_ratio: effectiveRatio,
                n: 1,
                ...(isSyncMode ? { isSync: true } : {}), // 线路二添加同步标识
                ...imagePayload
            };
            generateImageApi(apiKey, payload)
              .then((res: any) => {
                 if (res.taskId) {
                   onUpdateGeneration(pid, null, undefined, res.taskId);
                 } else if (res.data && res.data[0] && res.data[0].url) {
                   onUpdateGeneration(pid, res.data[0].url);
                 } else if (res.url) {
                   onUpdateGeneration(pid, res.url);
                 } else {
                   onUpdateGeneration(pid, null, "未知返回格式");
                 }
              })
              .catch((err: any) => { onUpdateGeneration(pid, null, err.message); });
          });
        };

        if (isDoubao) {
          // Doubao models support multi-image array natively
          const imageArray = refSrcs.map(src => src.includes(',') ? src.split(',')[1] : src);
          processSubmission({ image: imageArray });
        } else {
          // Legacy/Gemini models still use collage
          createCollageFromSrcs(refSrcs).then(collageBase64 => {
            const compositePrompt = referenceImages.length > 1 ? `[多图参考] 输入是 ${referenceImages.length} 张图片的拼贴。${currentPrompt}` : currentPrompt;
            processSubmission({ 
              image: collageBase64.split(',')[1],
              images: [collageBase64.split(',')[1]]
            }, compositePrompt);
          }).catch((err: any) => { setError(err.message); });
        }
      } else {
        const placeholderIds = onInitGenerations(quantity, currentPrompt, effectiveRatio);
        const modelName = getModelName();
        placeholderIds.forEach(pid => {
          const payload: any = {
              model: modelName,
              prompt: currentPrompt,
              size: getEffectiveSize(modelName),
              aspect_ratio: effectiveRatio,
              n: 1,
              ...(isSyncMode ? { isSync: true } : {}) // 线路二添加同步标识
          };
          generateImageApi(apiKey, payload)
            .then((res: any) => {
              if (res.taskId) {
                onUpdateGeneration(pid, null, undefined, res.taskId);
              } else if (res.data && res.data[0] && res.data[0].url) {
                onUpdateGeneration(pid, res.data[0].url);
              } else if (res.url) {
                onUpdateGeneration(pid, res.url);
              } else {
                onUpdateGeneration(pid, null, "未知返回格式");
              }
            })
            .catch((err: any) => { onUpdateGeneration(pid, null, err.message || "生成失败"); });
        });
      }
    }
  };

  const handleVideoSubmit = async () => {
    console.log("Video Submit triggered", { prompt, apiKey, videoModel });
    if (!prompt.trim()) {
      setError("请输入提示词");
      return;
    }
    if (!apiKey) {
      setError("请先设置API密钥");
      return;
    }

    // 自动在提示词后添加比例参数供模型参考 (双重保障)
    const promptWithRatio = `${prompt.trim()} --ar ${videoAspectRatio}`;
    const currentPrompt = promptWithRatio;

    // Init generation node (VIDEO type)
    const placeholderIds = onInitGenerations(1, currentPrompt, '16:9', undefined, 'VIDEO');
    const pid = placeholderIds[0];

    try {
      // Convert reference images to base64 on client side (browser environment)
      // This is necessary because assetStorage (IndexedDB) is not available in Node.js backend
      const base64Images: string[] = [];
      
      if (referenceImages && referenceImages.length > 0) {
        for (const imgRef of referenceImages) {
          try {
            let blob: Blob | undefined;

            // Priority 1: Use directly stored blob object (fastest, no CSP issue)
            if (imgRef.blob) {
              blob = imgRef.blob;
            }
            // Priority 2: Get from assetStorage
            else if (imgRef.assetId) {
              const storedBlob = await assetStorage.getBlob(imgRef.assetId);
              if (!storedBlob) {
                throw new Error('Asset not found in storage');
              }
              blob = storedBlob;
            }
            // Priority 3: Data URL (convert to blob)
            else if (imgRef.src.startsWith('data:image')) {
              const res = await fetch(imgRef.src);
              blob = await res.blob();
            }
            // Priority 4: HTTP/HTTPS URL (external images)
            else if (imgRef.src.startsWith('http')) {
              const response = await fetch(imgRef.src);
              if (!response.ok) {
                throw new Error(`Failed to fetch: ${response.status}`);
              }
              blob = await response.blob();
            }
            // Priority 5: Blob URL (local preview images)
            else if (imgRef.src.startsWith('blob:')) {
              const response = await fetch(imgRef.src);
              if (!response.ok) {
                throw new Error(`Failed to fetch blob: ${response.status}`);
              }
              blob = await response.blob();
            }
            else {
              throw new Error(`Unsupported image source: ${imgRef.src.substring(0, 50)}`);
            }

            if (blob) {
              // Ensure blob is a valid Blob instance (fixes "Overload resolution failed" in strict environments/builds)
              // Sometimes objects passed around lose their prototype chain or are duck-typed
              const safeBlob = blob instanceof Blob ? blob : new Blob([blob as any], { type: (blob as any).type || 'image/png' });

              // Compress/Resize Image
              const base64 = await new Promise<string>((resolve, reject) => {
                const img = new Image();
                const url = URL.createObjectURL(safeBlob);
                
                img.onload = () => {
                  URL.revokeObjectURL(url);
                  let width = img.width;
                  let height = img.height;
                  const MAX_DIM = 1280; // Limit resolution to reduce payload size

                  if (width > MAX_DIM || height > MAX_DIM) {
                    if (width > height) {
                      height = Math.round((height * MAX_DIM) / width);
                      width = MAX_DIM;
                    } else {
                      width = Math.round((width * MAX_DIM) / height);
                      height = MAX_DIM;
                    }
                  }

                  const canvas = document.createElement('canvas');
                  canvas.width = width;
                  canvas.height = height;
                  const ctx = canvas.getContext('2d');
                  if (!ctx) {
                    reject(new Error("Canvas context failed"));
                    return;
                  }

                  // Fill white background for transparency handling (optional but good for JPEG)
                  ctx.fillStyle = '#FFFFFF';
                  ctx.fillRect(0, 0, width, height);
                  ctx.drawImage(img, 0, 0, width, height);

                  // Export as JPEG quality 0.85
                  const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
                  resolve(dataUrl.split(',')[1]);
                };
                
                img.onerror = (e) => {
                   URL.revokeObjectURL(url);
                   reject(new Error("Image load failed")); 
                };
                
                img.src = url;
              });

              base64Images.push(base64);
            }

          } catch (error) {
            console.error('Failed to process reference image:', error);
            throw new Error(`参考图处理失败: ${error instanceof Error ? error.message : '未知错误'}`);
          }
        }
      }

      const videoUrl = await generateVideo(apiKey, videoModel, currentPrompt, base64Images.length > 0 ? base64Images : undefined, (progress) => {
        if (onUpdateProgress) onUpdateProgress(pid, progress);
      }, {
        aspect_ratio: videoAspectRatio,
        hd: videoHd,
        duration: videoDuration
      });
      onUpdateGeneration(pid, videoUrl);
    } catch (err: any) {
      onUpdateGeneration(pid, null, err.message || "视频生成失败");
    }
  };

  // Wrap original submit to handle video mode
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isVideoMode) {
      handleVideoSubmit();
    } else {
      handleSubmit(e);
    }
  };

  const handleInputFocus = () => { /* onRegisterHistory(); */ };
  // 优化提示词处理 (Modified to support Video type)
  const handleOptimizePrompt = async () => {
    if (!prompt.trim()) {
      setError("请先输入提示词");
      return;
    }
    if (!apiKey) {
      setError("请先在设置中输入 API Key");
      return;
    }

    setIsOptimizing(true);
    setError(null);
    setShowOptionsPanel(false); // Reset panel

    try {
      const type = isVideoMode ? 'VIDEO' : 'IMAGE';
      const options = await optimizePrompt(apiKey, prompt, type);
      setPromptOptions(options);
      setSelectedOptionIndex(0);
      setShowOptionsPanel(true);
      // Auto-apply the first option? No, let user choose.
      // But maybe we can preview it?
    } catch (e: any) {
      setError(e.message || "优化失败，请重试");
    } finally {
      setIsOptimizing(false);
    }
  };

  // 方案切换处理
  const handlePrevOption = () => {
    setSelectedOptionIndex(prev => (prev > 0 ? prev - 1 : promptOptions.length - 1));
  };

  const handleNextOption = () => {
    setSelectedOptionIndex(prev => (prev < promptOptions.length - 1 ? prev + 1 : 0));
  };

  // 确认选择方案
  const handleConfirmOption = () => {
    if (promptOptions.length > 0 && promptOptions[selectedOptionIndex]) {
      setPrompt(promptOptions[selectedOptionIndex].prompt);
      setShowOptionsPanel(false);
      setPromptOptions([]);
    }
  };

  // 关闭方案选择面板
  const handleCloseOptions = () => {
    setShowOptionsPanel(false);
    setPromptOptions([]);
  };

    // 标题图标和文字根据选中的模型动态变化
  const getImageModelTitle = () => {
    switch (imageModel) {
      case 'gemini-flash': return 'Nano Banana 2';
      case 'doubao-seedream-5-0-260128': return '即梦5.0';
      case 'doubao-seedream-4-5-251128': return '即梦4.5';
      case 'z-image-turbo': return 'Z-image -turbo';
      default: return 'Nano Banana Pro';
    }
  };

  const getImageTitleIcon = () => {
    switch (imageModel) {
      case 'doubao-seedream-5-0-260128': return <Sparkles size={20} className="text-purple-400 drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]" />;
      case 'doubao-seedream-4-5-251128': return <Layers size={20} className="text-blue-400 drop-shadow-[0_0_8px_rgba(96,165,250,0.5)]" />;
      case 'z-image-turbo': return <Zap size={20} className="text-blue-400 drop-shadow-[0_0_8px_rgba(96,165,250,0.5)]" />;
      default: return <Banana size={20} className="text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)] transform -rotate-12" />;
    }
  };

  const titleIcon = getImageTitleIcon();
  const titleText = (
    <span className="bg-linear-to-r from-yellow-200 via-yellow-400 to-orange-500 bg-clip-text text-transparent font-black tracking-tighter drop-shadow-sm italic text-lg pr-2">
      {getImageModelTitle()}
    </span>
  );

  const videoTitleText =      <span className="bg-gradient-to-r from-blue-300 via-purple-300 to-indigo-300 bg-clip-text text-transparent italic">
      AIGC Video
      </span>;

  const ratioOptions = [
    { label: '智能', value: 'Smart' },
    { label: '自定义', value: 'Custom' },
    { label: '1:1', value: '1:1' },
    { label: '16:9', value: '16:9' },
    { label: '9:16', value: '9:16' },
    { label: '4:3', value: '4:3' },
    { label: '3:4', value: '3:4' },
    { label: '3:2', value: '3:2' },
    { label: '2:3', value: '2:3' },
    { label: '21:9', value: '21:9' },
    { label: '9:21', value: '9:21' },
    { label: '5:4', value: '5:4' }
  ];

  // CRITICAL FIX: Move isMobile state BEFORE conditional return to avoid hooks rule violation
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
       const mobile = window.innerWidth < 640; // Match App.tsx threshold
       setIsMobile(mobile);
       if (mobile && panelRef.current) {
         // Reset transform on mobile so it sticks to bottom
         panelRef.current.style.transform = 'none';
       } else if (panelRef.current) {
         // Restore transform on desktop
         updatePanelTransform(posRef.current.x, posRef.current.y);
       }
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Auto-collapse logic
  useEffect(() => {
    if (isMobile || isDragging || panelMinimized || isGenerating || isHovered || isPinned) {
      setAutoCollapsed(false);
      if (hoverTimerRef.current) clearTimeout(hoverTimerRef.current);
      return;
    }

    // When mouse stands still outside panel for 2.5s, collapse it
    hoverTimerRef.current = setTimeout(() => {
       setAutoCollapsed(true);
    }, 2500);

    return () => {
      if (hoverTimerRef.current) clearTimeout(hoverTimerRef.current);
    }
  }, [isHovered, isDragging, panelMinimized, isMobile, isGenerating, isPinned]);

  // 不显示面板的条件
  if (!isControlPanelOpen) return null;

  // 面板样式
  const panelStyle: React.CSSProperties = isMobile ? {
    position: 'fixed',
    bottom: 0,
    left: 0,
    width: '100%',
    maxHeight: '60vh',
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    zIndex: 40,
    willChange: 'auto'
  } : {
    position: 'fixed',
    top: 0,
    left: 0,
    width: autoCollapsed ? '24px' : '320px',
    zIndex: 40,
    cursor: autoCollapsed ? 'pointer' : (isDragging ? 'grabbing' : 'default'),
    willChange: 'transform, width',
    transition: isDragging ? 'none' : 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
  };

  const desktopWidthClass = autoCollapsed 
    ? 'w-6 h-32 ml-0 rounded-r-2xl border-l-0 opacity-40 hover:opacity-100 overflow-hidden' 
    : 'rounded-[28px] w-[320px] overflow-hidden';

  // Remove backdrop blur during drag for performance
  const panelClass = isDragging 
      ? "bg-black/90 border border-white/20 rounded-[28px] shadow-none flex flex-col overflow-hidden"
      : `bg-[#121212]/95 backdrop-blur-xl border border-white/10 ${isMobile ? 'rounded-t-[28px] w-full max-h-[80vh] overflow-hidden' : desktopWidthClass} shadow-[0_30px_60px_rgba(0,0,0,0.6)] flex flex-col transition-all duration-300`;

  const safeDragStart = (e: React.MouseEvent) => {
    // Enable dragging on mobile too, but maybe restrict axis if needed. 
    // For now, allow free drag if user wants, or vertical only?
    // Let's allow standard drag but handle touch events if needed (mouse event handles touch simulation often)
    if (!autoCollapsed) handleDragStart(e);
  };

  return (
    <div 
       ref={panelRef} 
       style={panelStyle} 
       className={panelClass}
       onMouseEnter={() => autoCollapsed ? setAutoCollapsed(false) : setIsHovered(true)}
       onMouseLeave={() => setIsHovered(false)}
    >
      {autoCollapsed && !isMobile ? (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white/5 pointer-events-none gap-1.5 transition-all">
          <div className="w-1 h-3 bg-white/20 rounded-full"></div>
          <div className="w-1 h-12 bg-white/40 rounded-full shadow-[0_0_8px_rgba(255,255,255,0.3)]"></div>
          <div className="w-1 h-3 bg-white/20 rounded-full"></div>
        </div>
      ) : (
        <>
          {/* 头部 - UNIFIED HEADER WITH TITLE */}
          <div 
            className="border-b border-white/5 bg-white/5 backdrop-blur-md select-none touch-none"
            onMouseDown={safeDragStart}
            onTouchStart={handleTouchStartRaw}
          >
            <div className="flex items-center justify-center py-3 cursor-grab active:cursor-grabbing hover:bg-white/5 transition-colors">
          <div className="w-16 h-1.5 rounded-full bg-white/20"></div>
        </div>
        
        {!panelMinimized && (
        <div className="px-4 pb-3">
           <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-gray-200 flex items-center gap-2 select-none">
                {isVideoMode ? <MonitorPlay size={20} className="text-blue-400" /> : titleIcon}
                {isVideoMode ? videoTitleText : getImageModelTitle()}
              </h2>
               <div className="flex items-center gap-1">
                 <button
                  onClick={() => setIsPinned(!isPinned)}
                  className={`p-1.5 hover:bg-white/10 rounded-full transition-colors ${isPinned ? 'text-blue-400 bg-blue-500/10' : 'text-gray-400 hover:text-white'}`}
                  title={isPinned ? "取消固定" : "固定面板 (取消自动隐藏)"}
                 >
                   {isPinned ? <Pin size={14} className="fill-current" /> : <PinOff size={14} />}
                 </button>
                 <button
                  onClick={() => setPanelMinimized(true)}
                  className="text-gray-400 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition-colors"
                 >
                   <Minus size={14} />
                 </button>
                 <button
                  onClick={() => setControlPanelOpen(false)}
                  className="text-gray-400 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition-colors"
                 >
                   <X size={14} />
                 </button>
               </div>
           </div>
        </div>
        )}
        
        {/* Minimized Header */}
        {panelMinimized && (
          <div className="px-4 pb-3 flex items-center justify-between">
             <div className="text-xs font-bold text-white flex items-center gap-2 select-none">
               {isVideoMode ? <MonitorPlay size={16} className="text-blue-400" /> : getImageTitleIcon()}
               {isVideoMode ? 'AI 视频工作站' : getImageModelTitle()}
             </div>
             <div className="flex items-center gap-1">
               <button
                onClick={() => setIsPinned(!isPinned)}
                className={`p-1.5 hover:bg-white/10 rounded-full transition-colors ${isPinned ? 'text-blue-400 bg-blue-500/10' : 'text-gray-400 hover:text-white'}`}
                title={isPinned ? "取消固定" : "固定面板"}
               >
                 {isPinned ? <Pin size={14} className="fill-current" /> : <PinOff size={14} />}
               </button>
               <button
                onClick={() => setPanelMinimized(false)}
                className="text-gray-400 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition-colors"
               >
                 <Maximize2 size={14} />
               </button>
               <button
                onClick={() => setControlPanelOpen(false)}
                className="text-gray-400 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition-colors"
               >
                 <X size={14} />
               </button>
             </div>
          </div>
        )}
      </div>

      {/* 内容区域 */}
      {!panelMinimized && (
        <div className="p-4 flex flex-col gap-4 max-h-[85vh] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
          {/* 参考图区域 (For both Image and Video modes now) */}
          {/* 参考图区域 - hide in inpaint mode */}
          {toolMode !== ToolMode.INPAINT && (
              <div id="reference-drop-zone" 
                   className="border border-dashed border-gray-600 rounded-lg p-3 bg-gray-800/30 relative"
                   onDrop={handlePanelDrop} 
                   onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                   // onClick={() => alert(`[Click Debug] Max=${isVideoMode ? (VIDEO_LOSS_CONFIG[videoModel as any]?.max) : 10}, Current=${referenceImages.length}`)}
              >
                  {/* VISIBLE DEBUG info */}
                  {/* <div className="absolute top-0 right-0 bg-red-600 text-white text-[10px] px-1 pointer-events-none z-50">
                     DEBUG: Max={isVideoMode ? (VIDEO_LOSS_CONFIG[videoModel as any]?.max) : 10} / Count={referenceImages.length}
                  </div> */}

                <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-400">参考图</span>
                <button onClick={() => panelFileInputRef.current?.click()} className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
                  <Upload size={12} /> 上传
                </button>
              </div>
              {referenceImages.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {referenceImages.map((item, idx) => {
                    const config = isVideoMode ? VIDEO_LOSS_CONFIG[videoModel as keyof typeof VIDEO_LOSS_CONFIG] : null;
                    const label = config?.labels?.[idx];

                    return (
                    <div
                      key={item.id || idx}
                      className={`relative w-14 h-14 rounded overflow-hidden border ${draggingIndex === idx ? 'border-blue-500' : 'border-gray-600'}`}
                      draggable
                      onDragStart={(e) => handleRefDragStart(e, idx)}
                      onDrop={(e) => handleRefDrop(e, idx)}
                      onDragOver={(e) => e.preventDefault()}
                    >
                      <img src={item.src} alt="" className="w-full h-full object-cover" />
                      
                      {/* Frame Label (Start/End) */}
                      {label && (
                        <div className="absolute inset-x-0 bottom-0 bg-black/60 backdrop-blur-sm py-0.5 text-center">
                            <span className="text-[9px] text-white font-medium block leading-none scale-90">{label}</span>
                        </div>
                      )}

                      <button onClick={() => removeReferenceImage(idx)} className="absolute top-0 right-0 bg-red-500/80 text-white p-0.5 rounded-bl hover:bg-red-600">
                        <X size={10} />
                      </button>
                      {!label && (
                        <div className="absolute bottom-0 left-0 bg-black/50 text-white text-[8px] px-1">
                            <GripVertical size={8} className="inline" />
                        </div>
                      )}
                    </div>
                  )})}
                  
                  {/* Dynamic Add Button Logic */}
                  {(() => {
                     const maxImages = isVideoMode 
                        ? (VIDEO_LOSS_CONFIG[videoModel as keyof typeof VIDEO_LOSS_CONFIG]?.max || 1) 
                        : 10;
                     
                     if (referenceImages.length < maxImages) {
                         return (
                            <button onClick={() => panelFileInputRef.current?.click()} className="w-14 h-14 rounded border border-dashed border-gray-600 flex items-center justify-center text-gray-500 hover:text-gray-400 hover:border-gray-500 transition-colors">
                              <Plus size={16} />
                            </button>
                         );
                     }
                     return null;
                  })()}
                </div>
              ) : (
                <div className="text-center py-4 text-gray-500 text-xs">将图片拖拽到此处，或点击右上角上传</div>
              )}
              <input ref={panelFileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handlePanelFileSelect} />
            </div>
          )}



          {/* 表单 */}
          <form onSubmit={handleFormSubmit} className="flex flex-col gap-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs text-gray-400">提示词</label>
                <button
                  type="button"
                  onClick={handleOptimizePrompt}
                  disabled={isOptimizing || !prompt.trim()}
                  className={`text-xs flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${isOptimizing || !prompt.trim() ? 'text-gray-500 cursor-not-allowed' : 'text-yellow-400 hover:text-yellow-300 hover:bg-yellow-900/20'}`}
                >
                  {isOptimizing ? <Loader2 size={10} className="animate-spin" /> : <Sparkles size={10} />}
                  优化 (0.5币)
                </button>
              </div>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onFocus={handleInputFocus}
                placeholder={isVideoMode ? "描述你想要生成的视频内容..." : "描述你想要生成的图片..."}
                className="w-full h-24 min-h-24 bg-white/5 border border-white/10 rounded-xl p-3 text-sm text-gray-100 resize-y focus:border-purple-500/50 focus:bg-white/10 focus:outline-none transition-all placeholder:text-gray-500"
              />




              {/* 提示词方案选择卡片 */}
              {showOptionsPanel && promptOptions.length > 0 && (
                <div className="mt-3 bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                  {/* 卡片头部 */}
                  <div className="flex items-center justify-between px-3 py-2 bg-linear-to-r from-purple-500/20 to-blue-500/20 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <Sparkles size={12} className="text-purple-400" />
                      <span className="text-xs text-purple-300 font-medium">
                        优化方案 ({selectedOptionIndex + 1}/{promptOptions.length})
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={handlePrevOption}
                        className="p-1 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded transition-colors"
                        title="上一个方案"
                      >
                        <ChevronLeft size={14} />
                      </button>
                      <button
                        type="button"
                        onClick={handleNextOption}
                        className="p-1 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded transition-colors"
                        title="下一个方案"
                      >
                        <ChevronRight size={14} />
                      </button>
                      <button
                        type="button"
                        onClick={handleCloseOptions}
                        className="p-1 text-gray-400 hover:text-red-400 hover:bg-gray-700/50 rounded transition-colors ml-1"
                        title="关闭"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  </div>

                  {/* 卡片内容 */}
                  <div className="p-3">
                    {/* 风格标签 */}
                    <div className="flex items-center gap-2 mb-2">
                      <span className="px-2 py-0.5 bg-purple-600/40 text-purple-200 text-[10px] font-medium rounded-full">
                        {promptOptions[selectedOptionIndex]?.style || '优化结果'}
                      </span>
                    </div>

                    {/* 提示词预览 */}
                    <div className="text-xs text-gray-300 leading-relaxed max-h-32 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600">
                      {promptOptions[selectedOptionIndex]?.prompt || ''}
                    </div>
                  </div>

                  {/* 方案指示器 */}
                  <div className="flex items-center justify-center gap-1.5 py-2 border-t border-gray-700/50">
                    {promptOptions.map((_, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedOptionIndex(idx)}
                        className={`w-2 h-2 rounded-full transition-all ${idx === selectedOptionIndex
                          ? 'bg-purple-500 scale-110'
                          : 'bg-gray-600 hover:bg-gray-500'
                          }`}
                      />
                    ))}
                  </div>

                  {/* 确认按钮 */}
                  <div className="px-3 pb-3">
                    <button
                      type="button"
                      onClick={handleConfirmOption}
                      className="w-full py-2 bg-linear-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white text-xs font-medium rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-lg"
                    >
                      <Check size={12} />
                      使用此方案
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* 动态表单区域 */}
            {isVideoMode ? <VideoFormConfig /> : <ImageFormConfig />}

            {error && (
              <div className="text-red-400 text-xs bg-red-900/20 border border-red-800/50 rounded p-2">{error}</div>
            )}

            <button
              type="submit"
              disabled={isGenerating || (!prompt.trim() && toolMode !== ToolMode.INPAINT)}
              className={`w-full py-2.5 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-all ${isGenerating || (!prompt.trim() && toolMode !== ToolMode.INPAINT) ? 'bg-gray-700 text-gray-500 cursor-not-allowed' : 'bg-linear-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white shadow-lg'}`}
            >
              {isGenerating ? (
                <><Loader2 size={16} className="animate-spin" />正在工作中...</>
              ) : (
                <>
                  {toolMode === ToolMode.INPAINT ? <Zap size={16} /> : (isVideoMode ? <Film size={16} /> : <Wand2 size={16} />)}
                  {toolMode === ToolMode.INPAINT ? '执行局部重绘' : (isVideoMode ? '立即生成视频' : '立即开始创作')}
                </>
              )}
            </button>
            {/* Removed Exit Edit Mode button as Edit Mode is disabled */}
          </form>
        </div>
      )}
      </>
      )}
      <VideoPricingModal isOpen={showPricingModal} onClose={() => setShowPricingModal(false)} />
    </div>
  );
});

export default ControlPanel;
