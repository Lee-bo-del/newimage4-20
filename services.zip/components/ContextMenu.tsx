import React from 'react';
import { useSelectionStore } from '../src/store/selectionStore';
import { useCanvasStore } from '../src/store/canvasStore';
import { Copy, Trash2, ArrowUp, ArrowDown, ArrowUpToLine, ArrowDownToLine, Wand2, Download, Eye, ImagePlus, Link, Eraser } from 'lucide-react';
import { ToolMode } from '../types';

interface ContextMenuProps {
  onDuplicate: () => void;
  onRemoveBackground: () => void;
  onDownload: () => void;
  onCopyLink: () => void;
}

const ContextMenu: React.FC<ContextMenuProps> = ({
  onDuplicate,
  onRemoveBackground,
  onDownload,
  onCopyLink
}) => {
  // Get state from stores
  const { contextMenu, closeContextMenu, openLightbox, addReferenceImage, clearSelection, setToolMode, setInpaintWindowOpen } = useSelectionStore();
  const { nodes, deleteNode, reorderNode, addToHistory } = useCanvasStore();

  // Extract nodeId and coordinates early (before conditional return)
  const nodeId = contextMenu?.nodeId;
  const x = contextMenu?.x || 0;
  const y = contextMenu?.y || 0;

  // Don't render if no context menu
  if (!contextMenu) return null;
  const node = nodes.find(n => n.id === nodeId);
  const isImageNode = node?.type === 'IMAGE';

  // Prevent menu from going off-screen
  const style = {
    top: Math.min(y, window.innerHeight - 380),
    left: Math.min(x, window.innerWidth - 200),
  };

  const handleView = () => {
    if (node?.src) {
      openLightbox(node.src);
    }
    closeContextMenu();
  };

  const handleSetReference = () => {
    closeContextMenu();
    if (node?.src && node.type === 'IMAGE') {
      // Use setTimeout to allow menu to close visually before state changes that might cause layout shifts
      setTimeout(() => {
        addReferenceImage(node.src);
        clearSelection();
        setToolMode('GENERATE' as any);
      }, 10);
    }
  };

  const handleInpaint = () => {
    closeContextMenu();
    setToolMode(ToolMode.INPAINT);
    setInpaintWindowOpen(true);
  };

  const handleReorder = (direction: 'up' | 'down' | 'top' | 'bottom') => {
    addToHistory();
    reorderNode(nodeId, direction);
    closeContextMenu();
  };

  const handleDelete = () => {
    addToHistory();
    deleteNode(nodeId);
    closeContextMenu();
  };

  return (
    <div
      className="fixed z-50 w-48 bg-gray-900 border border-gray-700 rounded-lg shadow-2xl overflow-hidden text-sm"
      style={style}
      onMouseLeave={closeContextMenu}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex flex-col py-1">
        {isImageNode && (
          <button onClick={handleView} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
            <Eye size={14} className="text-green-400" />
            <span>放大预览 (Lightbox)</span>
          </button>
        )}

        {isImageNode && (
          <button onClick={handleSetReference} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
            <ImagePlus size={14} className="text-orange-400" />
            <span>设为参考图 (Img2Img)</span>
          </button>
        )}

        {isImageNode && (
          <button onClick={handleInpaint} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
            <Eraser size={14} className="text-purple-400" />
            <span>局部重绘 (Inpaint)</span>
          </button>
        )}

        {isImageNode ? (
          <button onClick={onDownload} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
            <Download size={14} className="text-blue-400" />
            <span>保存图片 (原图)</span>
          </button>
        ) : (
          <button onClick={onCopyLink} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
            <Link size={14} className="text-blue-400" />
            <span>复制视频链接</span>
          </button>
        )}

        <div className="h-px bg-gray-800 my-1" />




        <button onClick={onDuplicate} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
          <Copy size={14} />
          <span>复制图层</span>
        </button>

        <div className="h-px bg-gray-800 my-1" />

        <button onClick={() => handleReorder('top')} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
          <ArrowUpToLine size={14} />
          <span>置于顶层</span>
        </button>
        <button onClick={() => handleReorder('up')} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
          <ArrowUp size={14} />
          <span>上移一层</span>
        </button>
        <button onClick={() => handleReorder('down')} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
          <ArrowDown size={14} />
          <span>下移一层</span>
        </button>
        <button onClick={() => handleReorder('bottom')} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-800 text-left text-gray-200">
          <ArrowDownToLine size={14} />
          <span>置于底层</span>
        </button>

        <div className="h-px bg-gray-800 my-1" />

        <button onClick={handleDelete} className="flex items-center gap-2 px-4 py-2 hover:bg-red-900/30 text-left text-red-300">
          <Trash2 size={14} />
          <span>删除图层</span>
        </button>
      </div>
    </div>
  );
};

export default ContextMenu;
