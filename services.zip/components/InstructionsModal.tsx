import React from 'react';
import { X, HelpCircle, Sparkles, Image as ImageIcon, Box, LayoutGrid, History, CheckCircle2, Film } from 'lucide-react';

interface InstructionsModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const InstructionsModal: React.FC<InstructionsModalProps> = ({ isOpen, onClose }) => {
    const sections = [
        {
            icon: <Sparkles className="text-blue-400" size={20} />,
            title: "1. 功能支持",
            content: "提供提示词优化、图片提示词逆推。支持即梦 (Doubao) 5.0/4.5 原生多图参考。图片及视频生成任务均在后端自动运行，无需等待即可继续操作其他任务。"
        },
        {
            icon: <LayoutGrid className="text-purple-400" size={20} />,
            title: "2. 画布管理",
            content: "画布上的内容支持一键打包下载。您可以随时使用“整理”按钮对图片进行排版，或点击“清空”重启创作。"
        },
        {
            icon: <Box className="text-orange-400" size={20} />,
            title: "3. 批量文生图",
            content: "支持通过文档/表格批量解析。系统会将自然段自动拆分为提示词组，解析后请您认真核对内容。"
        },
        {
            icon: <ImageIcon className="text-green-400" size={20} />,
            title: "4. 批量图生图",
            content: "您可以一次上传多张参考图并共用同一个提示词。系统将根据每张参考图分别生成对应的全新图片。"
        },
        {
            icon: <History className="text-pink-400" size={20} />,
            title: "5. 历史记录",
            content: "所有生成的图片和视频均会自动保存。支持一键下载、预览，及将历史图再次拖入画布或设为参考图。"
        },
        {
            icon: <Film className="text-red-400" size={20} />,
            title: "6. AI 视频生成",
            content: "支持 Sora-2 (Pro)、Veo 3.1 及 Grok 系列顶级模型。Veo 模型支持首尾帧控制（图生视频）及多图融合功能。视频生成消耗较高，具体请参阅【计费说明】。"
        }
    ];

    return !isOpen ? null : (
        <div
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
            onClick={onClose}
        >
            <div
                className="bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col"
                onClick={e => e.stopPropagation()}
            >
                {/* Header */}
                <div className="flex items-center justify-between p-5 border-b border-gray-800 bg-gray-900/50">
                    <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                            <HelpCircle size={18} className="text-blue-400" />
                        </div>
                        <div>
                            <h2 className="text-base font-bold text-white leading-tight">使用说明</h2>
                            <p className="text-[10px] text-gray-500 mt-0.5">关于 Nano Banana Pro 版本使用指导</p>
                        </div>
                    </div>
                    <button
                        onClick={onClose}
                        className="text-gray-500 hover:text-white transition-colors p-1.5 hover:bg-gray-800 rounded-full"
                    >
                        <X size={20} />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-5 space-y-5 custom-scrollbar">
                    {sections.map((sec, idx) => (
                        <div key={idx} className="flex gap-4 group">
                            <div className="mt-1 shrink-0 p-2 bg-gray-800/50 rounded-xl border border-gray-700/50 group-hover:border-blue-500/30 transition-colors">
                                {sec.icon}
                            </div>
                            <div className="space-y-1">
                                <h3 className="text-sm font-bold text-gray-100">{sec.title}</h3>
                                <p className="text-xs text-gray-400 leading-relaxed font-normal">
                                    {sec.content}
                                </p>
                            </div>
                        </div>
                    ))}

                    <div className="mt-4 p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl flex items-start gap-3">
                        <CheckCircle2 size={16} className="text-blue-400 mt-0.5 shrink-0" />
                        <p className="text-[11px] text-blue-300 leading-relaxed">
                            提示：若在使用过程中遇到问题，请检查网络连接或确认 API Key 余额是否充足。
                        </p>
                    </div>
                </div>

                {/* Footer */}
                <div className="p-5 border-t border-gray-800 bg-gray-950/20">
                    <button
                        onClick={onClose}
                        className="w-full bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold py-2.5 rounded-xl transition-all shadow-lg shadow-blue-600/20 active:scale-[0.98]"
                    >
                        我明白了
                    </button>
                </div>
            </div>
        </div>
    );
};

export default InstructionsModal;
