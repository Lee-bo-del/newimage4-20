import React, { useRef, useState, useEffect } from 'react';
import { useSelectionStore } from '../src/store/selectionStore';
import { useCanvasStore } from '../src/store/canvasStore';
import { AppStatus, ToolMode, NodeData } from '../types';
import { X, Eraser, Trash2, Loader2, Sparkles, Move } from 'lucide-react';
import { renderMaskToDataURL, getBase64FromUrl } from '../src/utils/imageUtils';
import { editImageApi } from '../src/services/api';
import { useGenerationLogic } from '../src/hooks/useGenerationLogic';
import Draggable from 'react-draggable';

export const InpaintWindow: React.FC = () => {
    const { 
        isInpaintWindowOpen, setInpaintWindowOpen, 
        toolMode, setToolMode,
        selectedIds, apiKey, prompt, setPrompt,
        quantity, setQuantity,
    } = useSelectionStore();
    
    const { nodes, updateNode } = useCanvasStore();
    const { handleInitGenerations: onInitGenerations, handleUpdateGeneration: onUpdateGeneration } = useGenerationLogic();

    const [error, setError] = useState<string | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const panelRef = useRef<HTMLDivElement>(null);

    // Initial positioning based on window size
    const posRef = useRef({ x: 0, y: 0 });
    useEffect(() => {
        // Position slightly offset from the top left
        posRef.current = { x: 50, y: 100 };
    }, []);

    if (!isInpaintWindowOpen) return null;

    const selectedNode = selectedIds.length === 1 ? nodes.find(n => n.id === selectedIds[0]) : null;
    const isImageSelected = selectedNode?.type === 'IMAGE' && !selectedNode.loading;
    const hasStrokes = selectedNode?.maskStrokes && selectedNode.maskStrokes.length > 0;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim()) {
            setError("请输入提示词");
            return;
        }
        if (!apiKey.trim()) {
            setError("请先在设置中输入 API Key");
            return;
        }
        if (!selectedNode || !selectedNode.src || !hasStrokes) {
            setError("请先在画布上的图片涂抹出要重绘的区域 (必须有遮罩笔触)");
            return;
        }

        setError(null);
        setIsSubmitting(true);

        try {
            // ONLY ALLOW NANO BANANA 2-2K FOR INPAINTING
            const reqModelName = 'nano-banana-2-2k';
            const effectiveRatio = '1:1'; // Doesn't strictly matter for nano-banana-2 but provide a default

            const img = new Image();
            img.crossOrigin = 'anonymous';
            
            img.onload = () => {
                const intrinsicWidth = img.naturalWidth;
                const intrinsicHeight = img.naturalHeight;
                
                const maskBase64 = renderMaskToDataURL(null, intrinsicWidth, intrinsicHeight, selectedNode.width, selectedNode.height, selectedNode.maskStrokes!, false);
                const punchedImageBase64 = renderMaskToDataURL(img, intrinsicWidth, intrinsicHeight, selectedNode.width, selectedNode.height, selectedNode.maskStrokes!, false);
                
                const placeholderIds = onInitGenerations(quantity, prompt, effectiveRatio, selectedNode);
            
                getBase64FromUrl(selectedNode.src!).then(base64Image => {
                    placeholderIds.forEach(pid => {
                        const payload: any = {
                            model: reqModelName,
                            prompt,
                            n: 1,
                            // nano-banana-2 expects the punched image and ignores separation mask
                            image: punchedImageBase64.split(',')[1],
                            mask: maskBase64.split(',')[1],
                            image_size: '2K', 
                            aspect_ratio: effectiveRatio,
                        };

                        editImageApi(apiKey, payload)
                            .then((res: { taskId: string }) => {
                                onUpdateGeneration(pid, null, undefined, res.taskId);
                            })
                            .catch((err: any) => { 
                                onUpdateGeneration(pid, null, err.message || "重绘失败"); 
                            });
                    });
                }).catch(err => {
                    placeholderIds.forEach(pid => onUpdateGeneration(pid, null, "读取原图失败"));
                });
                
                // Clear strokes after sending
                updateNode(selectedNode.id, { maskStrokes: [] });
                setIsSubmitting(false);
            };

            img.onerror = () => {
                setError("无法读取原图片的原始尺寸数据 (跨域或加载失败)");
                setIsSubmitting(false);
            };

            img.src = selectedNode.src;

        } catch (err: any) {
            setError(err.message || "请求失败");
            setIsSubmitting(false);
        }
    };

    const handleClearStrokes = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (selectedNode) {
            updateNode(selectedNode.id, { maskStrokes: [] });
        }
    };

    const handleClose = () => {
        setInpaintWindowOpen(false);
        if (toolMode === ToolMode.INPAINT) {
            setToolMode(ToolMode.SELECT);
        }
    };

    return (
        <Draggable 
            nodeRef={panelRef} 
            handle=".drag-handle" 
            defaultPosition={posRef.current}
            onStop={(e: any, data: any) => { posRef.current = { x: data.x, y: data.y }; }}
            bounds="parent"
        >
            <div 
                ref={panelRef} 
                className="fixed z-50 w-80 bg-gray-900/90 backdrop-blur-3xl border border-gray-700/50 shadow-2xl rounded-2xl overflow-hidden flex flex-col"
                style={{ maxHeight: 'calc(100vh - 40px)', userSelect: 'none' }}
            >
                {/* Header (Drag Handle) */}
                <div className="drag-handle flex items-center justify-between px-4 py-3 border-b border-gray-800 cursor-move bg-gray-900/50 hover:bg-gray-800/50 transition-colors">
                    <div className="flex items-center gap-2">
                        <Eraser size={16} className="text-purple-400" />
                        <span className="font-bold text-sm bg-linear-to-r from-purple-400 to-indigo-400 text-transparent bg-clip-text">
                            局部重绘 (Inpaint)
                        </span>
                    </div>
                    <button 
                        onClick={handleClose} 
                        className="p-1 hover:bg-white/10 rounded-md transition-colors text-gray-400 hover:text-white"
                        title="关闭窗口"
                    >
                        <X size={16} />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 styled-scrollbar">
                    {/* Model Info Banner */}
                    <div className="flex items-center gap-2 p-3 bg-purple-900/20 border border-purple-500/30 rounded-xl mb-4">
                        <Sparkles size={14} className="text-purple-400 shrink-0" />
                        <div className="text-xs text-purple-200 leading-relaxed text-left">
                            <span className="font-semibold block mb-1">已锁定专属模型: Nano Banana Pro (2K)</span>
                            该模型专为局部涂抹重排优化，只支持对此模型的直接调用。
                        </div>
                    </div>

                    {!isImageSelected ? (
                        <div className="flex flex-col items-center justify-center py-8 text-gray-500 gap-3 border border-dashed border-gray-700 rounded-xl">
                            <Move size={24} className="opacity-50" />
                            <span className="text-xs text-center px-4">请先在画布上点击选中一张图片</span>
                        </div>
                    ) : (
                        <div className="flex flex-col gap-4">
                            {/* Mask Status */}
                            <div className="flex items-center justify-between">
                                <span className={'text-xs font-medium ' + (hasStrokes ? 'text-green-400' : 'text-gray-400')}>
                                    {hasStrokes ? '✓ 已检测到涂抹遮罩' : '提示: 请在图片上涂抹遮罩区域'}
                                </span>
                                {hasStrokes && (
                                    <button
                                        type="button"
                                        onClick={handleClearStrokes}
                                        className="flex items-center gap-1 px-2 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded text-[10px] transition-colors"
                                    >
                                        <Trash2 size={10} />
                                        清除笔触
                                    </button>
                                )}
                            </div>

                            <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-2">
                                {/* Prompt Input */}
                                <div className="space-y-1">
                                    <label className="text-[10px] text-gray-400 font-medium">重绘提示词</label>
                                    <textarea
                                        value={prompt}
                                        onChange={(e) => setPrompt(e.target.value)}
                                        placeholder="描述涂抹区域内想要生成的内容，例如：一只可爱的小猫..."
                                        className="w-full h-24 bg-black/40 border border-gray-800 rounded-xl p-3 text-sm focus:outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500 resize-none transition-all placeholder:text-gray-600"
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' && !e.shiftKey) {
                                                e.preventDefault();
                                                handleSubmit(e);
                                            }
                                        }}
                                    />
                                </div>

                                {/* Quantity Input */}
                                <div>
                                    <label className="block text-[10px] text-gray-500 mb-1">生成张数</label>
                                    <select 
                                        value={quantity}
                                        onChange={(e) => setQuantity(parseInt(e.target.value))}
                                        className="w-full bg-black/40 border border-gray-800 rounded-lg px-3 py-2 text-xs text-white outline-hidden cursor-pointer hover:border-gray-700 focus:border-purple-500"
                                    >
                                        <option value={1}>1</option>
                                        <option value={2}>2</option>
                                        <option value={4}>4</option>
                                    </select>
                                </div>

                                {error && (
                                    <div className="p-2.5 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs text-left">
                                        {error}
                                    </div>
                                )}

                                {/* Submit Button */}
                                <button
                                    type="submit"
                                    disabled={!hasStrokes || isSubmitting}
                                    className={`
                                        relative group overflow-hidden
                                        w-full py-3.5 rounded-xl font-bold text-sm text-white shadow-xl transition-all duration-300
                                        ${!hasStrokes || isSubmitting 
                                            ? 'bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700/50' 
                                            : 'bg-linear-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 border border-purple-500/50 hover:shadow-purple-500/25 active:scale-[0.98]'
                                        }
                                    `}
                                >
                                    {isSubmitting ? (
                                        <div className="flex items-center justify-center gap-2">
                                            <Loader2 size={16} className="animate-spin" />
                                            <span>发送中...</span>
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-center gap-2">
                                            <Sparkles size={16} className={hasStrokes ? "animate-pulse" : ""} />
                                            <span>开始重绘</span>
                                        </div>
                                    )}
                                    {/* Shimmer effect */}
                                    {hasStrokes && !isSubmitting && (
                                        <div className="absolute inset-0 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] bg-linear-to-r from-transparent via-white/20 to-transparent skew-x-12" />
                                    )}
                                </button>
                            </form>
                        </div>
                    )}
                </div>
            </div>
        </Draggable>
    );
};

export default InpaintWindow;
