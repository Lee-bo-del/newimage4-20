const express = require("express");
const cors = require("cors");
const axios = require("axios");
const path = require("path");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const winston = require("winston");
const fs = require("fs");
const FormData = require("form-data");

// Logger Configuration
const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json(),
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: "debug_error.log" }),
  ],
});

const app = express();
const PORT = 3325;

// 上游 API 配置
const UPSTREAM_URL = "https://api.bltcy.ai";

// Security Middleware
// Security Middleware
app.use(
  helmet({
    contentSecurityPolicy: false, // Totally disable CSP to allow blob: and data: images
    crossOriginEmbedderPolicy: false,
  })
);

// ==================== Rate Limiting Configuration ====================
// For PUBLIC SERVICE: Per-user limits to ensure fair resource distribution

// Import the ipKeyGenerator helper for proper IPv6 support
const { ipKeyGenerator } = rateLimit;

// Helper: Extract user identifier (API Key or IP with proper IPv6 handling)
const getUserKey = (req) => {
  const apiKey = req.headers['authorization'];
  // Use API key if available, otherwise fall back to IP (with IPv6 support)
  return apiKey && apiKey.length > 10 ? apiKey : ipKeyGenerator(req);
};

// Global fallback limiter (per user)
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 1500,                  // 1500 requests per user per 15 minutes (increased for public service)
  keyGenerator: getUserKey,
  standardHeaders: true,
  legacyHeaders: false,
  message: "请求过于频繁，请稍后再试"
});

// Polling endpoints - per user, high frequency
const pollingLimiter = rateLimit({
  windowMs: 60 * 1000,       // 1 minute
  max: 50,                    // 50 requests per user per minute (allows ~2-3 concurrent tasks per user)
  keyGenerator: getUserKey,
  standardHeaders: true,
  legacyHeaders: false,
  message: "轮询请求过于频繁，请稍后再试"
});

// Generation endpoints - per user, moderate limits
const generateLimiter = rateLimit({
  windowMs: 60 * 1000,       // 1 minute
  max: 10,                    // 10 generation requests per user per minute
  keyGenerator: getUserKey,
  standardHeaders: true,
  legacyHeaders: false,
  message: "生成请求过于频繁，请稍后再试"
});

// Announcement endpoint - per IP, very lenient (read-only)
const announcementLimiter = rateLimit({
  windowMs: 60 * 1000,       // 1 minute
  max: 100,                   // 100 requests per IP per minute
  keyGenerator: ipKeyGenerator, // Use official helper for IPv6 support
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: "公告服务暂时不可用"
});

// Apply global limiter only to API routes, not static files
app.use("/api", globalLimiter);

app.use(cors());
app.use(express.json({ limit: "50mb" })); // 支持大图片 Base64

// ==================== 余额查询接口 ====================
app.get("/api/balance/info", async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const startDate = "2023-01-01";
    const now = new Date();
    now.setDate(now.getDate() + 1);
    const endDate = now.toISOString().split("T")[0];

    const [subRes, usageRes] = await Promise.all([
      axios.get(`${UPSTREAM_URL}/v1/dashboard/billing/subscription`, {
        headers: { Authorization: userKey },
      }),
      axios.get(
        `${UPSTREAM_URL}/v1/dashboard/billing/usage?start_date=${startDate}&end_date=${endDate}`,
        {
          headers: { Authorization: userKey },
        },
      ),
    ]);

    const subData = subRes.data;
    const usageData = usageRes.data;

    // 积分计算公式: 1 USD = 25 金币
    const POINTS_MULTIPLIER = 25;
    let totalQuotaUsd = parseFloat(subData.hard_limit_usd || 0);
    let usedAmountUsd = 0;
    if (usageData && usageData.total_usage !== undefined) {
      usedAmountUsd = parseFloat(usageData.total_usage) / 100;
    }

    let remainingBalanceUsd = totalQuotaUsd - usedAmountUsd;
    if (remainingBalanceUsd < 0) remainingBalanceUsd = 0;

    // 新积分公式
    const total_points = Math.floor(totalQuotaUsd * POINTS_MULTIPLIER);
    const used_points = Math.floor(usedAmountUsd * POINTS_MULTIPLIER);
    const remaining_points = total_points - used_points;

    res.json({
      success: true,
      status_valid: remainingBalanceUsd > 0.05,
      remaining_points: remaining_points,
      used_points: used_points,
      total_points: total_points,
    });
  } catch (error) {
    console.error("Balance Check Error:", error.message);
    if (error.response && error.response.status === 401) {
      res.status(401).json({ error: "API Key 无效或已过期" });
    } else {
      res.status(500).json({ error: "查询余额失败，请稍后重试" });
    }
  }
});

// ==================== 生图代理接口 ====================
app.post("/api/generate", generateLimiter, async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const requestBody = req.body;
    
    // Resolution mapping for Doubao and Z-image models
    const DOUBAO_RESOLUTIONS = {
      "1K": {
        "1:1": "1024x1024", "4:3": "1152x864", "3:4": "864x1152", "16:9": "1424x800",
        "9:16": "800x1424", "3:2": "1248x832", "2:3": "832x1248", "21:9": "1568x672"
      },
      "2K": {
        "1:1": "2048x2048", "4:3": "2304x1728", "3:4": "1728x2304", "16:9": "2848x1600",
        "9:16": "1600x2848", "3:2": "2496x1664", "2:3": "1664x2496", "21:9": "3136x1344"
      },
      "3K": {
        "1:1": "3072x3072", "4:3": "3456x2592", "3:4": "2592x3456", "16:9": "4096x2304",
        "9:16": "2304x4096", "2:3": "2496x3744", "3:2": "3744x2496", "21:9": "4704x2016"
      },
      "4K": {
        "1:1": "4096x4096", "4:3": "4704x3520", "3:4": "3520x4704", "16:9": "5504x3040",
        "9:16": "3040x5504", "2:3": "3328x4992", "3:2": "4992x3328", "21:9": "6240x2656"
      }
    };

    const isSyncLine = requestBody.isSync === true;
    if (isSyncLine) {
      delete requestBody.isSync; // 移除前端专用标识
    }

    const isDoubaoOrTurbo = requestBody.model?.startsWith('doubao') || 
                            requestBody.model?.startsWith('grok') ||
                            requestBody.model === 'z-image-turbo';

    if (isDoubaoOrTurbo) {
      // Doubao Expects 'image' as array for Seedream 4.5/5.0
      if (requestBody.model?.startsWith('doubao') && Array.isArray(requestBody.image)) {
        requestBody.sequential_image_generation = "auto";
        requestBody.response_format = "url";
      }
      
      // Size resolution mapping (skip if already WxH format from frontend)
      if (requestBody.size && !requestBody.size.includes('x')) {
        let sizeKey = requestBody.size.toUpperCase();
        const ratio = requestBody.aspect_ratio || "1:1";
        
        // Model validation/normalization
        if (requestBody.model.includes('5-0')) {
          // 即梦5.0: 2K or 3K
          if (sizeKey === '1K') sizeKey = '2K';
          if (sizeKey === '4K') sizeKey = '3K';
          if (!['2K', '3K'].includes(sizeKey)) sizeKey = '2K';
        } else if (requestBody.model.includes('4-5')) {
          // 即梦4.5: 2K or 4K
          if (sizeKey === '1K') sizeKey = '2K';
          if (sizeKey === '3K') sizeKey = '2K';
          if (!['2K', '4K'].includes(sizeKey)) sizeKey = '2K';
        } else if (requestBody.model === 'z-image-turbo') {
          // z-image-turbo: 固定 1K
          sizeKey = '1K';
        }

        // Apply resolution mapping if available
        if (DOUBAO_RESOLUTIONS[sizeKey] && DOUBAO_RESOLUTIONS[sizeKey][ratio]) {
          requestBody.size = DOUBAO_RESOLUTIONS[sizeKey][ratio];
          console.log(`[Resolution] Mapped ${sizeKey} ${ratio} to ${requestBody.size}`);
        } else {
          requestBody.size = sizeKey;
        }
      }
    }

    console.log("[Generate] Proxying request:", {
      model: requestBody.model,
      size: requestBody.size,
      ratio: requestBody.aspect_ratio,
      prompt: requestBody.prompt?.substring(0, 50) + "...",
      hasImage: !!requestBody.image,
      isSync: isSyncLine,
      imageType: Array.isArray(requestBody.image) ? "Array" : typeof requestBody.image,
    });

    const upstreamUrl = isSyncLine 
      ? `${UPSTREAM_URL}/v1/chat/completions` 
      : `${UPSTREAM_URL}/v1/images/generations?async=true`;

    // 如果是同步线路（Chat 接口），转换请求体
    let finalRequestBody = requestBody;
    if (isSyncLine) {
      finalRequestBody = {
        model: requestBody.model,
        messages: [
          { role: 'user', content: requestBody.prompt }
        ],
        stream: false
      };
    }

    const response = await axios.post(
      upstreamUrl,
      finalRequestBody,
      {
        headers: {
          Authorization: userKey,
          "Content-Type": "application/json",
        },
        timeout: 600000, // 600 秒 (10分钟) 超时
      }
    );

    // 如果是同步线路，解析 Chat 返回格式以提取 URL
    if (isSyncLine) {
      const chatContent = response.data.choices?.[0]?.message?.content || "";
      console.log("[Generate] Chat response content:", chatContent.substring(0, 100));
      
      const urlMatch = chatContent.match(/https?:\/\/[^\s^)^>]+/);
      if (urlMatch) {
         return res.json({ url: urlMatch[0] });
      } else {
         return res.json({ url: chatContent }); // 直接返回文本内容作为兜底
      }
    }

    console.log("[Generate] Upstream response:", response.data);
    res.json(response.data);
  } catch (error) {
    console.error("[Generate] Error:", error.message);
    logger.error({
      timestamp: new Date().toISOString(),
      type: "Generate Error",
      message: error.message,
      stack: error.stack,
      response: error.response?.data
    });

    if (error.response) {
      // 透传上游错误
      res.status(error.response.status).json(error.response.data);
    } else if (error.code === "ECONNABORTED") {
      res.status(504).json({ error: "请求超时，请稍后重试" });
    } else {
      res.status(500).json({ error: error.message || "生成请求失败" });
    }
  }
});

// ==================== 局部重绘代理接口 ====================
app.post("/api/edit", generateLimiter, async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const requestBody = req.body;
    
    console.log("[Edit] Proxying request:", {
      model: requestBody.model,
      size: requestBody.size,
      prompt: requestBody.prompt?.substring(0, 50) + "...",
      hasImage: !!requestBody.image,
      hasMask: !!requestBody.mask
    });

    const formData = new FormData();
    formData.append('model', requestBody.model);
    formData.append('prompt', requestBody.prompt);
    
    if (requestBody.n) formData.append('n', String(requestBody.n));
    if (requestBody.size) formData.append('size', requestBody.size);
    if (requestBody.image_size) formData.append('image_size', requestBody.image_size);
    if (requestBody.aspect_ratio) formData.append('aspect_ratio', requestBody.aspect_ratio);

    if (requestBody.image) {
      const imgBuffer = Buffer.from(requestBody.image, 'base64');
      formData.append('image', imgBuffer, { filename: 'image.png', contentType: 'image/png' });
    }
    
    if (requestBody.mask) {
      const maskBuffer = Buffer.from(requestBody.mask, 'base64');
      formData.append('mask', maskBuffer, { filename: 'mask.png', contentType: 'image/png' });
    }

    const response = await axios.post(
      `${UPSTREAM_URL}/v1/images/edits?async=true`,
      formData,
      {
        headers: {
          Authorization: userKey,
          ...formData.getHeaders()
        },
        timeout: 600000, 
      }
    );

    console.log("[Edit] Upstream response:", response.data);
    res.json(response.data);
  } catch (error) {
    console.error("[Edit] Error:", error.message);
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else if (error.code === "ECONNABORTED") {
      res.status(504).json({ error: "请求超时，请稍后重试" });
    } else {
      res.status(500).json({ error: error.message || "编辑请求失败" });
    }
  }
});

// ==================== 图片代理接口 (解决 CORS) ====================
app.get("/api/proxy/image", async (req, res) => {
  const imageUrl = req.query.url;
  if (!imageUrl) return res.status(400).send("Url is required");

  // Validate URL to prevent arbitrary proxying if possible, or at least check protocol
  if (!imageUrl.startsWith('http')) {
    return res.status(400).send("Invalid URL protocol");
  }

  try {
    console.log("[Image Proxy] Fetching:", imageUrl.substring(0, 100) + "...");
    const response = await axios.get(imageUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
      }
    });

    const contentType = response.headers['content-type'] || 'image/jpeg';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Buffer is better for res.send
    res.send(Buffer.from(response.data));
  } catch (error) {
    console.error("[Image Proxy] Error:", error.message);
    res.status(500).send("Failed to proxy image: " + error.message);
  }
});

// ==================== 任务轮询接口 ====================
app.get("/api/task/:taskId", pollingLimiter, async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const { taskId } = req.params;

    const response = await axios.get(
      `${UPSTREAM_URL}/v1/images/tasks/${taskId}`,
      {
        headers: {
          Authorization: userKey,
          "Content-Type": "application/json",
        },
        timeout: 10000,
      },
    );

    res.json(response.data);
  } catch (error) {
    console.error("[Task Poll] Error:", error.message);

    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ error: error.message || "任务查询失败" });
    }
  }
});

// ==================== Gemini 原生图片生成接口 ====================
app.post("/api/gemini/generate", generateLimiter, async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const { prompt, images, aspect_ratio, image_size, thinking_level, output_format } = req.body;
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "提示词不能为空" });
    }

    console.log("[Gemini Generate] Request:", {
      prompt: prompt.substring(0, 50) + "...",
      hasImages: !!(images && images.length > 0),
      imageCount: images ? images.length : 0,
      aspect_ratio,
      image_size,
      thinking_level,
    });

    // 构建 contents parts
    const parts = [];
    parts.push({ text: prompt });

    // 添加参考图（最多 14 张）
    if (images && images.length > 0) {
      for (const img of images.slice(0, 14)) {
        // 支持 data URL 和纯 base64
        let base64Data = img;
        let mimeType = "image/jpeg";
        if (img.startsWith("data:")) {
          const match = img.match(/^data:(image\/\w+);base64,(.+)$/);
          if (match) {
            mimeType = match[1];
            base64Data = match[2];
          }
        }
        parts.push({
          inline_data: {
            mime_type: mimeType,
            data: base64Data,
          },
        });
      }
    }

    // 构建 generationConfig（camelCase = Google 官方 REST 格式）
    const generationConfig = {
      response_modalities: output_format === 'IMAGE_ONLY' ? ["Image"] : ["Image", "Text"],
    };

    // 图片配置
    const imageConfig = {};
    if (aspect_ratio && aspect_ratio !== "Smart" && aspect_ratio !== "Auto") {
      imageConfig.aspect_ratio = aspect_ratio;
    }
    if (image_size) {
      imageConfig.image_size = image_size.toUpperCase();
    }
    if (Object.keys(imageConfig).length > 0) {
      generationConfig.image_config = imageConfig;
    }

    // 思考链配置
    if (thinking_level) {
      generationConfig.thinking_config = {
        thinking_level: thinking_level.toUpperCase(),
      };
    }

    const requestBody = {
      contents: [
        {
          parts: parts,
        },
      ],
      generation_config: generationConfig,
    };

    // 打印实际请求体（脱敏图片数据）
    const debugBody = JSON.parse(JSON.stringify(requestBody));
    if (debugBody.contents?.[0]?.parts) {
      debugBody.contents[0].parts = debugBody.contents[0].parts.map(p => {
        if (p.inline_data) return { inline_data: { mime_type: p.inline_data.mime_type, data: "[BASE64...]" } };
        return p;
      });
    }
    console.log("[Gemini Generate] Request body:", JSON.stringify(debugBody, null, 2));

    const GEMINI_ENDPOINT = `${UPSTREAM_URL}/v1beta/models/gemini-3.1-flash-image-preview:generateContent`;

    let response;
    try {
      response = await axios.post(GEMINI_ENDPOINT, requestBody, {
        headers: {
          Authorization: userKey,
          "Content-Type": "application/json",
        },
        timeout: 300000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
      });
    } catch (firstErr) {
      // 如果 snake_case 格式失败，尝试 camelCase 格式
      if (firstErr.response?.status === 400) {
        console.log("[Gemini Generate] snake_case failed, trying camelCase format...");
        const camelBody = {
          contents: requestBody.contents,
          generationConfig: {
            responseModalities: output_format === 'IMAGE_ONLY' ? ["IMAGE"] : ["IMAGE", "TEXT"],
          },
        };
        if (Object.keys(imageConfig).length > 0) {
          camelBody.generationConfig.imageConfig = {};
          if (imageConfig.aspect_ratio) camelBody.generationConfig.imageConfig.aspectRatio = imageConfig.aspect_ratio;
          if (imageConfig.image_size) camelBody.generationConfig.imageConfig.imageSize = imageConfig.image_size;
        }
        if (thinking_level) {
          camelBody.generationConfig.thinkingConfig = { thinkingLevel: thinking_level.toUpperCase() };
        }
        
        try {
          response = await axios.post(GEMINI_ENDPOINT, camelBody, {
            headers: { Authorization: userKey, "Content-Type": "application/json" },
            timeout: 300000, maxContentLength: Infinity, maxBodyLength: Infinity,
          });
        } catch (secondErr) {
          // 如果还是失败，尝试不带 generationConfig
          if (secondErr.response?.status === 400) {
            console.log("[Gemini Generate] camelCase also failed, trying without generationConfig...");
            const minimalBody = { contents: requestBody.contents };
            response = await axios.post(GEMINI_ENDPOINT, minimalBody, {
              headers: { Authorization: userKey, "Content-Type": "application/json" },
              timeout: 300000, maxContentLength: Infinity, maxBodyLength: Infinity,
            });
          } else {
            throw secondErr;
          }
        }
      } else {
        throw firstErr;
      }
    }

    // 从响应中提取图片
    const candidates = response.data?.candidates;
    if (!candidates || candidates.length === 0) {
      return res.status(500).json({ error: "生成失败：未返回结果" });
    }

    const resultImages = [];
    let resultText = "";

    for (const candidate of candidates) {
      if (!candidate.content || !candidate.content.parts) continue;
      for (const part of candidate.content.parts) {
        if (part.inlineData && part.inlineData.data) {
          const mimeType = part.inlineData.mimeType || "image/png";
          const dataUrl = `data:${mimeType};base64,${part.inlineData.data}`;
          resultImages.push(dataUrl);
        } else if (part.inline_data && part.inline_data.data) {
          // 兼容 snake_case 格式
          const mimeType = part.inline_data.mime_type || "image/png";
          const dataUrl = `data:${mimeType};base64,${part.inline_data.data}`;
          resultImages.push(dataUrl);
        } else if (part.text) {
          resultText += part.text;
        }
      }
    }

    if (resultImages.length === 0) {
      return res.status(500).json({
        error: "生成失败：未返回图片",
        text: resultText || undefined,
      });
    }

    console.log(`[Gemini Generate] Success, ${resultImages.length} image(s) generated`);
    res.json({
      success: true,
      images: resultImages,
      text: resultText || undefined,
    });
  } catch (error) {
    console.error("[Gemini Generate] Error:", error.message);
    // 打印完整的上游错误响应
    if (error.response?.data) {
      console.error("[Gemini Generate] Upstream response:", JSON.stringify(error.response.data));
    }
    logger.error({
      timestamp: new Date().toISOString(),
      type: "Gemini Generate Error",
      message: error.message,
      status: error.response?.status,
      response: error.response?.data,
    });

    if (error.response) {
      const errData = error.response.data;
      const errMsg =
        errData?.error?.message ||
        (typeof errData === "string" ? errData : JSON.stringify(errData));
      res.status(error.response.status).json({ error: errMsg });
    } else if (error.code === "ECONNABORTED") {
      res.status(504).json({ error: "请求超时，请稍后重试" });
    } else {
      res.status(500).json({ error: error.message || "Gemini 生成请求失败" });
    }
  }
});

// ==================== 视频生成接口 ====================
app.post("/api/video/generate", generateLimiter, async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const requestBody = req.body;
    // Detailed File Logging
    const logEntry = {
      timestamp: new Date().toISOString(),
      type: "Video Request",
      keys: Object.keys(requestBody),
      has_image_url: !!requestBody.image_url,
      has_image: !!requestBody.image,
      prompt: requestBody.prompt,
      model: requestBody.model,
      options: {
        aspect_ratio: requestBody.aspect_ratio,
        hd: requestBody.hd,
        duration: requestBody.duration,
      },
    };

    logger.info(logEntry);

    console.log("[Video Generate] Proxying request:", {
      model: requestBody.model,
      prompt: requestBody.prompt?.substring(0, 50) + "...",
      hasImage: !!requestBody.image_url || !!requestBody.image,
    });

    // ---- Grok Video 参数重映射 ----
    // Grok 的 API 使用不同的字段名，需要在服务端做一次转换
    const upstreamBody = { ...requestBody };
    if (upstreamBody.model && String(upstreamBody.model).startsWith('grok-video')) {
      // aspect_ratio -> ratio
      if (upstreamBody.aspect_ratio !== undefined) {
        upstreamBody.ratio = upstreamBody.aspect_ratio;
        delete upstreamBody.aspect_ratio;
      }
      // hd -> resolution (720P / 1080P)
      upstreamBody.resolution = upstreamBody.hd ? '1080P' : '720P';
      delete upstreamBody.hd;
      // duration -> integer
      if (upstreamBody.duration !== undefined) {
        upstreamBody.duration = parseInt(upstreamBody.duration, 10);
      }
      // image / image_url -> images array
      if (upstreamBody.image || upstreamBody.image_url) {
        upstreamBody.images = [upstreamBody.image || upstreamBody.image_url];
        delete upstreamBody.image;
        delete upstreamBody.image_url;
      }
      console.log("[Video Generate] Grok remapped body:", JSON.stringify(Object.keys(upstreamBody)));
    }

    const response = await axios.post(
      `${UPSTREAM_URL}/v2/videos/generations`, // New V2 Endpoint
      upstreamBody,
      {
        headers: {
          Authorization: userKey,
          "Content-Type": "application/json",
        },
        timeout: 900000, // 900 秒 (15分钟) 超时
      },
    );

    console.log("[Video Generate] Upstream response:", response.data);
    res.json(response.data);
  } catch (error) {
    console.error("[Video Generate] Error:", error.message);
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ error: error.message || "视频生成请求失败" });
    }
  }
});

// ==================== 视频任务轮询接口 ====================
app.get("/api/video/task/:taskId", pollingLimiter, async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey) return res.status(401).json({ error: "无效的 API Key" });

    const { taskId } = req.params;

    const url = `${UPSTREAM_URL}/v2/videos/generations/${taskId}`;
    console.log(`[Video Task Poll] Requesting: ${url}`);

    const response = await axios.get(url, {
      headers: {
        Authorization: userKey,
        "Content-Type": "application/json",
      },
      timeout: 10000,
    });

    logger.info({
      timestamp: new Date().toISOString(),
      type: "Poll Response",
      taskId,
      responsePreview: JSON.stringify(response.data).substring(0, 1000),
    });

    console.log(
      "[Video Task Poll] Response:",
      JSON.stringify(response.data).substring(0, 500),
    );
    res.json(response.data);
  } catch (error) {
    console.error("[Video Task Poll] Error:", error.message);
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ error: error.message || "视频任务查询失败" });
    }
  }
});

// ==================== 提示词优化接口 ====================
app.post("/api/optimize-prompt", async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const { prompt, type = "IMAGE" } = req.body;
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "提示词不能为空" });
    }

    console.log(
      `[Optimize] Optimizing ${type} prompt:`,
      prompt.substring(0, 50) + "...",
    );

    const GEMINI_ENDPOINT =
      "https://api.bltcy.ai/v1beta/models/gemini-3-flash-preview:generateContent";

    // 针对 Nano Banana Pro 格式优化的系统指令 (图片)
    const imageSystemInstruction = `你是一个专业的 AI 图像生成提示词专家，专门为 Google Nano Banana Pro (Gemini 3 Pro Image) 模型优化提示词。

用户会给你一个简单的图像描述，你需要生成 3 个不同风格的中文提示词方案。

## Nano Banana Pro 提示词格式要求：
1. 使用自然语言描述，像给人类艺术家简报一样，使用完整句子
2. 避免"标签堆砌"格式（如 "猫, 公园, 4k, 写实"）
3. 每个提示词应包含以下核心元素：
   - 主体: 清晰具体地描述主体特征
   - 构图: 镜头角度、取景方式 (如 特写镜头, 广角镜头, 低角度拍摄)
   - 动作: 主体正在做什么
   - 场景: 环境和背景描述
   - 风格: 艺术或摄影风格
   - 光线: 光线条件描述

## 输出要求：
生成 3 个不同风格的方案，必须严格按照以下 JSON 格式输出，不要有任何其他文字：
[
  {
    "style": "写实摄影",
    "prompt": "详细的中文提示词，描述一张写实摄影风格的照片..."
  },
  {
    "style": "艺术插画",
    "prompt": "详细的中文提示词，描述一幅艺术插画风格的作品..."
  },
  {
    "style": "电影质感",
    "prompt": "详细的中文提示词，描述一个电影质感的画面..."
  }
]

重要规则：
- style 字段用中文（写实摄影、艺术插画、电影质感）
- prompt 字段必须是详细的中文描述，约 50-100 个中文字
- 只输出有效的 JSON 格式，不要有 markdown 标记或其他解释`;

    // 针对 Sora 2 / Veo 3.1 格式优化的系统指令 (视频)
    const videoSystemInstruction = `你是一个专业的 AI 视频生成提示词专家，专门为 Sora 2 和 Veo 3.1 等高端视频模型优化提示词。

用户会给你一个简单的视频描述，你需要生成 3 个不同风格的中文视频提示词方案。

## Sora 2 / Veo 3.1 视频提示词关键要素：
1. **动态优先**：必须详细描述画面中的运动、变化和物理交互。
2. **运镜描述**：明确指定摄影机的运动方式（如 "推镜头 (Dolly in)", "无人机航拍 (Drone shot)", "平移 (Pan right)"）。
3. **物理连贯性**：强调光影变化、流体动态、布料飘动等物理细节。
4. **时间流逝**：如果适用，描述随时间发生的变化。

## 提示词结构：
[主体与核心动作] + [详细的运镜与拍摄手法] + [环境氛围与光影] + [视频质感与风格]

## 输出要求：
生成 3 个不同风格的方案，必须严格按照以下 JSON 格式输出，不要有任何其他文字：
[
  {
    "style": "写实电影",
    "prompt": "详细的中文视频提示词，包含具体的运镜和动态描述..."
  },
  {
    "style": "创意短片",
    "prompt": "详细的中文视频提示词，侧重创意视角和独特动态..."
  },
  {
    "style": "史诗大片",
    "prompt": "详细的中文视频提示词，宏大的场面和震撼的运镜..."
  }
]

重要规则：
- style 字段用中文
- prompt 字段必须是详细的中文描述，约 80-150 个中文字，重点在于描述"动起来"的画面
- 只输出有效的 JSON 格式，不要有 markdown 标记或其他解释`;

    const systemInstruction =
      type === "VIDEO" ? videoSystemInstruction : imageSystemInstruction;

    const response = await axios.post(
      GEMINI_ENDPOINT,
      {
        contents: [{ parts: [{ text: prompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] },
      },
      {
        headers: {
          Authorization: userKey,
          "Content-Type": "application/json",
        },
        timeout: 30000,
      },
    );

    const candidates = response.data?.candidates;
    if (!candidates || candidates.length === 0) {
      return res.status(500).json({ error: "优化失败：未返回结果" });
    }

    const rawText = candidates[0]?.content?.parts?.[0]?.text;
    if (!rawText) {
      return res.status(500).json({ error: "优化失败：结果格式错误" });
    }

    // 尝试解析 JSON 数组
    let options;
    try {
      // 清理可能的 markdown 代码块标记
      let cleanedText = rawText.trim();
      if (cleanedText.startsWith("```json")) {
        cleanedText = cleanedText.slice(7);
      } else if (cleanedText.startsWith("```")) {
        cleanedText = cleanedText.slice(3);
      }
      if (cleanedText.endsWith("```")) {
        cleanedText = cleanedText.slice(0, -3);
      }
      cleanedText = cleanedText.trim();

      options = JSON.parse(cleanedText);

      if (!Array.isArray(options) || options.length === 0) {
        throw new Error("Invalid options format");
      }
    } catch (parseError) {
      console.error(
        "[Optimize] JSON parse error:",
        parseError.message,
        "Raw:",
        rawText.substring(0, 200),
      );
      // 如果解析失败，返回单个选项作为兼容
      return res.json({
        success: true,
        options: [{ style: "优化结果", prompt: rawText.trim() }],
      });
    }

    console.log("[Optimize] Success, generated", options.length, "options");
    res.json({ success: true, options });
  } catch (error) {
    console.error("[Optimize] Error:", error.message);

    if (error.response) {
      res
        .status(error.response.status)
        .json({ error: error.response.data?.error?.message || "优化请求失败" });
    } else if (error.code === "ECONNABORTED") {
      res.status(504).json({ error: "请求超时，请稍后重试" });
    } else {
      res.status(500).json({ error: error.message || "优化请求失败" });
    }
  }
});

// ==================== 图片逆推 API ====================
app.post("/api/reverse-prompt", async (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    if (!userKey || userKey.length < 10) {
      return res.status(401).json({ error: "无效的 API Key" });
    }

    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: "图片数据不能为空" });
    }

    // 移除 Base64 前缀 (如果存在)
    const base64Image = image.replace(
      /^data:image\/(png|jpeg|webp);base64,/,
      "",
    );

    console.log("[Reverse] Analyzing image...");

    const GEMINI_ENDPOINT =
      "https://api.bltcy.ai/v1beta/models/gemini-3-flash-preview:generateContent";

    const systemInstruction = `你是一位拥有20年经验的资深视觉设计师和艺术总监。
你的任务是全方位地分析用户上传的图片，并生成一段详细的中文提示词（Prompt），以便再次生成风格和内容高度相似的图片。

请从以下几个维度进行专业分析：
1. **主体**：详细描述画面中心的人、物或元素，包括外貌、姿态、材质等。
2. **构图**：分析视角（如俯视、特写）、景别、画面布局。
3. **光影**：描述光线的来源、强度、色温以及阴影的表现。
4. **色彩**：分析主色调、配色方案、饱和度和对比度。
5. **风格**：判断图片的艺术风格（如写实摄影、赛博朋克、水彩插画、极简主义等）。
6. **氛围**：描述图片传达的情绪和氛围。

**输出要求**：
- 综合以上分析，输出一段连贯、流畅、细节丰富的**中文提示词**。
- 不要分点列出，直接输出一段完整的描述性文字。
- 不需要任何开场白或解释，直接输出提示词内容。`;

    const response = await axios.post(
      GEMINI_ENDPOINT,
      {
        contents: [
          {
            parts: [
              { text: "请基于这张图片生成详细的中文提示词：" },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: base64Image,
                },
              },
            ],
          },
        ],
        systemInstruction: { parts: [{ text: systemInstruction }] },
      },
      {
        headers: {
          Authorization: userKey,
          "Content-Type": "application/json",
        },
        timeout: 120000, // 120 秒超时
      },
    );

    const candidates = response.data?.candidates;
    if (!candidates || candidates.length === 0) {
      return res.status(500).json({ error: "逆推失败：未返回结果" });
    }

    const prompt = candidates[0]?.content?.parts?.[0]?.text;
    if (!prompt) {
      return res.status(500).json({ error: "逆推失败：结果格式错误" });
    }

    console.log("[Reverse] Success");
    res.json({ success: true, prompt: prompt.trim() });
  } catch (error) {
    console.error("[Reverse] Error:", error.message);

    if (error.response) {
      console.error(
        "[Reverse] API Error Details:",
        JSON.stringify(error.response.data),
      );
      res
        .status(error.response.status)
        .json({ error: error.response.data?.error?.message || "逆推请求失败" });
    } else if (error.code === "ECONNABORTED") {
      res.status(504).json({ error: "请求超时，请优化网络或稍后重试" });
    } else {
      res.status(500).json({ error: error.message || "逆推请求失败" });
    }
  }
});

// ==================== 静态文件服务 ====================
// ==================== 公告系统 API ====================
const ANNOUNCEMENT_FILE = path.join(__dirname, 'announcement.json');

// 获取当前公告
app.get("/api/announcement", announcementLimiter, (req, res) => {
  try {
    if (!fs.existsSync(ANNOUNCEMENT_FILE)) {
      // 默认无公告
      return res.json({ active: false, content: "", id: "", title: "" });
    }
    const data = fs.readFileSync(ANNOUNCEMENT_FILE, 'utf8');
    const announcement = JSON.parse(data);
    res.json(announcement);
  } catch (error) {
    console.error("[Announcement] Read Error:", error);
    res.status(500).json({ error: "无法读取公告数据" });
  }
});

// 发布/更新公告 (Admin)
app.post("/api/announcement", (req, res) => {
  try {
    const userKey = req.headers["authorization"];
    const adminPassword = req.headers["x-admin-password"];
    
    // 1. 基础鉴权：必须有 API Key
    if (!userKey || userKey.length < 5) {
      return res.status(401).json({ error: "请先配置 API Key" });
    }

    // 2. 管理员鉴权：必须提供正确的管理密码
    // 默认密码: admin888 (您可以修改此处或通过环境变量 ADMIN_PASSWORD 设置)
    const VALID_PASSWORD = process.env.ADMIN_PASSWORD || "admin888";
    
    if (adminPassword !== VALID_PASSWORD) {
      return res.status(403).json({ error: "管理员密码错误，无法发布" });
    }

    const { content, title, active } = req.body;
    
    const newAnnouncement = {
      id: Date.now().toString(), // 更新 ID 以便前端识别为新公告
      date: new Date().toISOString(),
      title: title || "系统公告",
      content: content || "",
      active: active === true // 明确布尔值
    };

    fs.writeFileSync(ANNOUNCEMENT_FILE, JSON.stringify(newAnnouncement, null, 2), 'utf8');
    
    console.log("[Announcement] Updated:", newAnnouncement);
    res.json({ success: true, announcement: newAnnouncement });
  } catch (error) {
    console.error("[Announcement] Write Error:", error);
    res.status(500).json({ error: "发布公告失败" });
  }
});

// ==================== 静态文件服务 ====================

// Serve static files from the build directory
app.use(express.static(path.join(__dirname, 'dist')));

// ==================== 健康检查 ====================
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Handle React routing, return all requests to React app
// MUST be the last route


app.listen(PORT, () => {
  console.log(`🚀 Backend server running on http://localhost:${PORT}`);
  console.log(`   Upstream API: ${UPSTREAM_URL}`);
});
