import { assetStorage } from '../src/services/assetStorage';

// Video Service for interacting with the backend video API

const API_BASE_URL = '/api';

const BASE_URL = '/api';

const cleanUrl = (url: string) => url.replace(/\/$/, "");

// Helper to wait
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

interface VideoGenerationResponse {
    id?: string;
    task_id?: string;
    data?: {
        task_id?: string;
    };
}

// Helper: Handle API Error
const handleApiError = async (response: Response) => {
    const errText = await response.text();
    
    // Handle authentication errors (invalid/expired API key)
    if (response.status === 401) {
        throw new Error("密钥错误：请检查密钥是否输入完整（需以 sk- 开头）");
    }
    
    const lowerErr = errText.toLowerCase();

    if (
        lowerErr.includes("token quota is not enough") ||
        (lowerErr.includes("remain quota") && lowerErr.includes("need quota")) ||
        lowerErr.includes("insufficient balance") ||
        lowerErr.includes("not enough balance") ||
        lowerErr.includes("credit") ||
        lowerErr.includes("quota")
    ) {
        throw new Error("你的密钥余额不足，请充值续费");
    }

    throw new Error(`Submission Failed (${response.status}): ${errText}`);
};

// Poll task
const pollVideoTask = async (apiKey: string, taskId: string, onProgress?: (progress: number) => void): Promise<string> => {
    const url = `${cleanUrl(BASE_URL)}/video/task/${taskId}`;
    const maxAttempts = 300; // 10 minutes (300 * 2s)

    const authHeader = apiKey.startsWith('Bearer ') ? apiKey : `Bearer ${apiKey}`;

    const startTime = Date.now();
    let lastProgress = 0;

    for (let i = 0; i < maxAttempts; i++) {
        await sleep(2000);

        try {
            // ... fetch logic ...
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Authorization': authHeader,
                    'Content-Type': 'application/json'
                }
            });

            // ... parse data ...
            let data: any = null;
            try {
                data = await response.json();
            } catch (e) { }

            if (!response.ok) {
                if (response.status === 404) continue;
                if (data) {
                    // ... failure check ...
                    let statusRaw = (data.status || data.state || "").toUpperCase();
                    if (data.data?.status) statusRaw = data.data.status.toUpperCase();
                    if (statusRaw === 'FAILURE' || statusRaw === 'FAILED') {
                        const reason = data.fail_reason || data.error?.message || (data.data?.error?.message) || "Unknown error";
                        throw new Error(`Task Failed: ${reason}`);
                    }
                }
                console.warn(`Polling HTTP error: ${response.status}`);
                continue;
            }

            if (!data) continue;

            // --- COMFORTING PROGRESS LOGIC ---

            // 1. Get Real Progress if available
            let realProgress: number | undefined = undefined;
            if (data.progress !== undefined) realProgress = data.progress;
            else if (data.data?.progress !== undefined) realProgress = data.data.progress;
            else {
                // Fuzzy search
                const findProgress = (obj: any): any => {
                    if (!obj || typeof obj !== 'object') return undefined;
                    for (const key of Object.keys(obj)) {
                        const k = key.toLowerCase();
                        if ((k === 'progress' || k === 'percentage' || k === 'percent') && typeof obj[key] !== 'object') {
                            return obj[key];
                        }
                    }
                    return undefined;
                };
                realProgress = findProgress(data);
            }

            // Normalize Real Progress (0-1 -> 0-100)
            let currentRealP = 0;
            if (realProgress !== undefined) {
                if (typeof realProgress === 'string') {
                    const s = realProgress as string;
                    currentRealP = s.includes('%') ? parseFloat(s.replace('%', '')) : parseFloat(s);
                } else if (typeof realProgress === 'number') {
                    currentRealP = realProgress;
                }
                if (!isNaN(currentRealP)) {
                    if (currentRealP <= 1 && currentRealP > 0 && !(typeof realProgress === 'string' && (realProgress as string).includes('%'))) {
                        currentRealP = currentRealP * 100;
                    }
                }
            }

            // 2. Status-based Baseline
            let statusRaw = (data.status || data.state || "").toUpperCase();
            if (data.data?.status) statusRaw = data.data.status.toUpperCase();

            let statusBaseline = 0;
            if (['RUNNING', 'PROCESSING', 'GENERATING', 'RENDERING'].includes(statusRaw)) {
                statusBaseline = 20; // Start running at 20%
            } else if (['QUEUED', 'PENDING', 'SUBMITTED', 'CREATED', 'WAITING', 'NOT_START'].includes(statusRaw)) {
                statusBaseline = 5;
            }

            // 3. Determine Target Progress
            // 4. Simulated Increment (Comforting)
            // Target 90% at 180s -> k approx 0.012
            const elapsed = (Date.now() - startTime) / 1000;
            const simulated = (1 - Math.exp(-0.012 * elapsed)) * 100;

            // Determine Target Progress (Max of Real, Baseline, Previous, Simulated)
            let targetProgress = Math.max(currentRealP, statusBaseline, lastProgress, simulated);

            // Cap at 99% until fully complete
            if (targetProgress > 99) targetProgress = 99;

            // 5. Update State & Emit
            lastProgress = targetProgress;

            if (onProgress) {
                onProgress(Math.floor(lastProgress));
            }

            // ... Existing Success/Fail Check ...

            // Unified format check (existing code follows)

            // Data might be nested
            if (data.data && typeof data.data === 'object') {
                if (data.data.status) statusRaw = data.data.status.toUpperCase();
            }

            const isSuccess = statusRaw === 'SUCCESS' || statusRaw === 'SUCCEEDED' || statusRaw === 'COMPLETED';
            const isFailed = statusRaw === 'FAILURE' || statusRaw === 'FAILED';

            if (isSuccess) {
                // Find video URL
                const findVideoUrl = (obj: any): string | null => {
                    if (!obj) return null;
                    if (obj.video_url) return obj.video_url;
                    if (obj.output && typeof obj.output === 'string' && obj.output.startsWith('http')) return obj.output; // Start checking output
                    if (obj.video && typeof obj.video === 'string' && obj.video.startsWith('http')) return obj.video; // Check simple video
                    if (obj.url && (obj.url.endsWith('.mp4') || (typeof obj.url === 'string' && obj.url.includes('video')))) return obj.url;
                    if (Array.isArray(obj)) {
                        for (const item of obj) {
                            const found = findVideoUrl(item);
                            if (found) return found;
                        }
                    }
                    if (typeof obj === 'object') {
                        // Deep search
                        for (const key in obj) {
                            if (typeof obj[key] === 'object' || Array.isArray(obj[key])) {
                                const found = findVideoUrl(obj[key]);
                                if (found) return found;
                            } else if ((key === 'video_url' || key === 'output' || key === 'video' || key === 'url') && typeof obj[key] === 'string' && (obj[key].endsWith('.mp4') || obj[key].startsWith('http'))) {
                                return obj[key];
                            }
                        }
                    }
                    return null;
                };

                const videoUrl = findVideoUrl(data);
                if (videoUrl) return videoUrl;
            } else if (isFailed) {
                const reason = data.fail_reason || data.error?.message || (data.data?.error?.message) || JSON.stringify(data);
                throw new Error(`Video Generation Failed: ${reason}`);
            }


        } catch (error: any) {
            // If we explicitly threw an error above (Task Failed), rethrow it break the loop
            if (error.message && (error.message.startsWith("Task Failed") || error.message.startsWith("Video Generation Failed"))) {
                throw error;
            }
            console.warn("Polling error:", error);
        }
    }
    throw new Error("Task timed out. No video returned.");
};

// Helper: Convert image to base64 (supports assetStorage, data URLs, and HTTP URLs)
const imageToBase64 = async (imageRef: { src: string; assetId?: string; type?: string }): Promise<string> => {
    try {
        let blob: Blob;

        // Case 1: Image from assetStorage (uploaded blob)
        if (imageRef.assetId) {
            const storedBlob = await assetStorage.getBlob(imageRef.assetId);
            if (!storedBlob) {
                throw new Error('Asset not found in storage');
            }
            blob = storedBlob;
        }
        // Case 2: Data URL (already base64)
        else if (imageRef.src.startsWith('data:image')) {
            // Extract base64 part (remove "data:image/png;base64," prefix)
            const base64Data = imageRef.src.split(',')[1];
            if (!base64Data) {
                throw new Error('Invalid data URL format');
            }
            return base64Data;
        }
        // Case 3: HTTP/HTTPS URL
        else if (imageRef.src.startsWith('http')) {
            const response = await fetch(imageRef.src);
            if (!response.ok) {
                throw new Error(`Failed to fetch image: ${response.status}`);
            }
            blob = await response.blob();
        }
        // Case 4: Blob URL (shouldn't happen after assetStorage, but handle it)
        else if (imageRef.src.startsWith('blob:')) {
            const response = await fetch(imageRef.src);
            blob = await response.blob();
        }
        else {
            throw new Error(`Unsupported image type: ${imageRef.src.substring(0, 20)}...`);
        }

        // Convert blob to base64
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = reader.result as string;
                // Remove data URL prefix to get pure base64
                const base64Data = base64.split(',')[1] || base64;
                resolve(base64Data);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    } catch (error) {
        console.error('Failed to convert image to base64:', error);
        throw new Error('图片转换失败，请检查图片链接是否有效');
    }
};
export const generateVideo = async (
    apiKey: string,
    model: string,
    prompt: string,
    base64Images?: string[], // Base64 strings (already converted on client side)
    onProgress?: (progress: number) => void,
    options?: {
        aspect_ratio?: string;
        hd?: boolean;
        duration?: string;
    }
): Promise<string> => {
    if (!apiKey) throw new Error("API Key is missing.");

    const endpoint = `${cleanUrl(BASE_URL)}/video/generate`;
    const authHeader = apiKey.startsWith('Bearer ') ? apiKey : `Bearer ${apiKey}`;

    let body: any = {};

    if (model.includes('veo')) {
        // Veo 3.1 API Format (Based on successful example)
        // Uses input_config with base64-encoded images
        
        const is4k = model.includes('4k');
        const duration = options?.duration ? parseInt(options.duration, 10) : 8;

        // Build input_config object
        // Build input_config object (Metadata only, heavy data via root 'images')
        const inputConfig: any = {
            aspect_ratio: options?.aspect_ratio || '16:9',
            duration: duration,
            generate_audio: true,
            resolution: is4k ? '4k' : '1080p'
        };

        // Note: We used to add images to inputConfig here, but now we send them 
        // at the root level ('images' array) to prevent payload doubling and 
        // ensure compatibility with the V2 wrapper which handles the mapping.

        body = {
            model,
            prompt,
            // Dual strategy: Send params at root for V2 wrapper compatibility
            aspect_ratio: options?.aspect_ratio || '16:9',
            images: base64Images, 
            input_config: inputConfig
        };

    } else {
        // Standard Sora Logic (V2)
        body = {
            model,
            prompt,
            ...options
        };

        // Duration should be string (V2 API)
        if (body.duration) {
            body.duration = String(body.duration).replace(/[sS]/g, '');
        }

        if (base64Images && base64Images.length > 0) {
            body.images = base64Images;
        }
    }


    console.log("[VideoService] Sending Veo Request:", JSON.stringify(body, null, 2));

    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Authorization': authHeader,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        await handleApiError(response);
    }

    const resJson: VideoGenerationResponse = await response.json();
    const taskId = resJson.id || resJson.task_id || (resJson.data && resJson.data.task_id);

    if (!taskId) throw new Error("No Task ID received from API.");

    return await pollVideoTask(apiKey, taskId, onProgress);
};
