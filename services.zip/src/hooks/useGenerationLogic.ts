import { useCallback } from 'react';
import { useCanvasStore } from '../store/canvasStore';
import { useSelectionStore } from '../store/selectionStore';
import { useHistoryStore } from '../store/historyStore';
import { assetStorage } from '../services/assetStorage';
import { arrangeNodes } from '../utils/layout';
import { NodeData, ToolMode } from '../../types';

export const useGenerationLogic = () => {
    const { nodes, setNodes, updateNode, generateId, setCanvasTransform, canvasState } = useCanvasStore();
    const { setToolMode, addLog } = useSelectionStore.getState() as any; // Cast to access non-state actions if any or mixed

    // Init generations (placeholder nodes)
    const handleInitGenerations = useCallback((count: number, prompt: string, aspectRatio: string = '1:1', baseNode?: NodeData, type: 'IMAGE' | 'VIDEO' = 'IMAGE') => {
        let width = 512;
        let height = 512;

        // Parse aspect ratio
        if (aspectRatio !== 'Smart' && aspectRatio) {
        const parts = aspectRatio.split(':').map(Number);
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
            const ratio = parts[0] / parts[1];
            if (ratio > 1) {
            // Landscape: Width 512, Height scaled
            width = 512;
            height = Math.round(512 / ratio);
            } else {
            // Portrait or Square: Height 512, Width scaled
            height = 512;
            width = Math.round(512 * ratio);
            }
        }
        } else if (baseNode) {
        // Smart mode with base node: inherit ratio
        const ratio = baseNode.width / baseNode.height;
        if (ratio > 1) {
            width = 512;
            height = Math.round(512 / ratio);
        } else {
            height = 512;
            width = Math.round(512 * ratio);
        }
        }

        const newNodes: NodeData[] = [];

        // Create new nodes
        for (let i = 0; i < count; i++) {
        newNodes.push({
            id: generateId(),
            type: type,
            x: 0,
            y: 0,
            width: width,
            height: height,
            opacity: 1,
            locked: false,
            loading: true,
            src: '',
            prompt: prompt,
            history: [],
            historyIndex: 0
        });
        }

        const currentNodes = useCanvasStore.getState().nodes;
        const allNodes = [...currentNodes, ...newNodes];

        // Arrange nodes (allNodes will use stable sort now, creating new columns)
        const finalNodes = arrangeNodes(allNodes, {
            startX: 360,
            startY: 100,
            gap: 20,
            maxRows: 3,
            nodeWidth: width,
            nodeHeight: height
        });

        setNodes(finalNodes);
        // Switch to SELECT mode so user can see what's happening
        setToolMode(ToolMode.SELECT);

        // Auto-pan to new nodes
        const newIds = new Set(newNodes.map(n => n.id));
        const arrangedNewNodes = finalNodes.filter(n => newIds.has(n.id));

        if (arrangedNewNodes.length > 0) {
            // Calculate bounding box of new nodes
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
            arrangedNewNodes.forEach(n => {
                minX = Math.min(minX, n.x);
                maxX = Math.max(maxX, n.x + n.width);
                minY = Math.min(minY, n.y);
                maxY = Math.max(maxY, n.y + n.height);
            });

            const centerX = (minX + maxX) / 2;
            const centerY = (minY + maxY) / 2;

            const screenCenterX = window.innerWidth / 2;
            const screenCenterY = window.innerHeight / 2;

            // Offset = ScreenCenter - CanvasCenter * Scale
            const newOffsetX = screenCenterX - centerX * canvasState.scale;
            const newOffsetY = screenCenterY - centerY * canvasState.scale;

            setCanvasTransform({ x: newOffsetX, y: newOffsetY }, canvasState.scale);
        }

        return newNodes.map(n => n.id);
    }, [generateId, setNodes, setToolMode, canvasState, setCanvasTransform]);

    // Update progress
    const handleUpdateProgress = useCallback((id: string, progress: number) => {
        updateNode(id, { progress }, true); 
    }, [updateNode]);

    // Update generation
    const handleUpdateGeneration = useCallback(async (id: string, src: string | null, error?: string, taskId?: string) => {
        if (taskId) {
            updateNode(id, { taskId, loading: true, error: false }, true);
            return;
        }

        if (error || !src) {
        updateNode(id, { loading: false, error: true, errorMessage: error });
        return;
        }

        const { addLog } = useHistoryStore.getState();

        // Detect video EARLY from original src (before proxy changes URL to blob:)
        const currentNodes0 = useCanvasStore.getState().nodes;
        const currentNode0 = currentNodes0.find(n => n.id === id);
        const isVideo = src.toLowerCase().endsWith('.mp4') 
            || src.toLowerCase().includes('format=mp4')
            || src.toLowerCase().includes('/video/')
            || currentNode0?.type === 'VIDEO';

        // Store asset if base64 or remote URL (to solve CORS and persistence)
        let finalSrc = src;
        let finalAssetId: string | undefined = undefined;

        if (src.startsWith('data:image') || src.startsWith('data:video') || src.startsWith('http')) {
            try {
                // Use proxy for remote URLs to bypass CORS
                const fetchUrl = src.startsWith('http') 
                    ? `/api/proxy/image?url=${encodeURIComponent(src)}`
                    : src;
                
                const res = await fetch(fetchUrl);
                if (res.ok) {
                    const blob = await res.blob();
                    finalAssetId = await assetStorage.storeBlob(blob);
                    const url = await assetStorage.getAssetUrl(finalAssetId);
                    if (url) finalSrc = url;
                }
            } catch (e) {
                console.error("Failed to store/proxy generated asset", e);
                // Fallback to original src
            }
        }

        // Use a clean update function to avoid duplication
        const finalizeUpdate = (imgWidth?: number, imgHeight?: number) => {
        const currentNodes = useCanvasStore.getState().nodes;
        const node = currentNodes.find(n => n.id === id);

        if (!node) {
            console.warn(`Node ${id} not found in store during update.`);
            return;
        }

        let newHeight = node.height;
        if (imgWidth && imgHeight && imgWidth > 0) {
            const aspectRatio = imgHeight / imgWidth;
            newHeight = node.width * aspectRatio;
        }

        updateNode(id, {
            src: finalSrc,
            assetId: finalAssetId,
            loading: false, // Turn off loading
            error: false,
            height: newHeight,
            opacity: 1
        });

        // Add to global generation history
        addLog(node.prompt || "Generated Image", finalSrc, finalAssetId);
        };

        // Video handling (detected early from original src)
        if (isVideo) {
        updateNode(id, {
            src: finalSrc,
            assetId: finalAssetId,
            loading: false,
            error: false,
            opacity: 1
        });
        addLog("Generated Video", finalSrc, finalAssetId);
        return;
        }

        const img = new Image();
        img.crossOrigin = "Anonymous";

        // Safety timeout
        const timeoutId = setTimeout(() => {
        console.warn("Image metadata load timed out, forcing update.");
        finalizeUpdate();
        }, 5000);

        img.onload = () => {
        clearTimeout(timeoutId);
        finalizeUpdate(img.naturalWidth, img.naturalHeight);
        };

        img.onerror = () => {
        clearTimeout(timeoutId);
        console.warn("Image metadata load failed.");
        updateNode(id, { loading: false, error: true, errorMessage: "Failed to load image" });
        };

        img.src = finalSrc;
    }, [updateNode]);

    return { handleInitGenerations, handleUpdateGeneration, handleUpdateProgress };
};
